-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: turntable.proxy.rlwy.net    Database: railway
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adresse`
--

DROP TABLE IF EXISTS `adresse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adresse` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `adresse1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `adresse2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `code_postal` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pays` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ville` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adresse`
--

LOCK TABLES `adresse` WRITE;
/*!40000 ALTER TABLE `adresse` DISABLE KEYS */;
INSERT INTO `adresse` VALUES (13,'2026-03-16 11:43:00.523041',NULL,'2026-03-16 11:43:00.523041','10 Rue de la Paix',NULL,'75001','France','Paris'),(14,'2026-03-16 17:12:07.400442',NULL,'2026-03-16 17:12:07.400442','10 Rue de la Paix',NULL,'75001','France','Paris'),(15,'2026-03-17 10:38:49.039555',NULL,'2026-03-17 10:38:49.039555','10 Rue de la Paix',NULL,'75001','France','Paris'),(16,'2026-03-17 10:58:48.595142',NULL,'2026-03-17 10:58:48.595142','25 Avenue des Technologies',NULL,'69001','France','Lyon'),(17,'2026-03-17 12:26:59.795223',NULL,'2026-03-17 12:26:59.795223','25 Avenue des Technologies',NULL,'69001','France','Lyon'),(18,'2026-03-17 12:36:23.529938',NULL,'2026-03-17 12:36:23.529938','25 Avenue des Technologies',NULL,'69001','France','Lyon'),(19,'2026-03-17 12:40:32.641166',NULL,'2026-03-17 12:40:32.641166','25 Avenue des Technologies',NULL,'69001','France','Lyon'),(20,'2026-03-17 12:45:55.896632',NULL,'2026-03-17 12:45:55.896632','25 Avenue des Technologies',NULL,'69001','France','Lyon'),(21,'2026-03-17 12:51:31.159059',NULL,'2026-03-17 12:51:31.159059','25 Avenue des Technologies',NULL,'69001','France','Lyon'),(22,'2026-03-17 13:32:27.786286',NULL,'2026-03-17 13:32:27.786286','5 Rue des Lilas',NULL,'75008','France','Paris'),(23,'2026-03-17 13:39:41.736912',NULL,'2026-03-17 13:39:41.736912','5 Rue des Lilas',NULL,'75008','France','Paris'),(24,'2026-03-25 13:04:54.556997',NULL,'2026-03-25 13:04:54.556997','15 Rue Victor Hugo','','69001','France','Lyon'),(25,'2026-03-25 13:09:04.153845',NULL,'2026-03-25 13:09:04.153845',' Square Brassens','','91600','France','Savigny-sur-Orge'),(26,'2026-03-25 13:09:37.840659',NULL,'2026-03-25 13:09:37.840659',' Square Brassens','','91600','France','Savigny-sur-Orge'),(27,'2026-03-25 13:10:06.350686',NULL,'2026-03-25 13:10:06.350686',' Square Brassens','','91600','France','Savigny-sur-Orge'),(28,'2026-03-25 13:10:15.712767',NULL,'2026-03-25 13:10:15.712767',' Square Brassens','','91600','France','Savigny-sur-Orge'),(29,'2026-03-25 13:10:41.520829',NULL,'2026-03-25 13:10:41.520829',' Square Brassens','','91600','France','Savigny-sur-Orge'),(30,'2026-03-25 13:10:57.908256',NULL,'2026-03-25 13:10:57.908256','5 Square Brassens','','91600','France','Savigny-sur-Orge'),(31,'2026-03-25 13:11:21.779326',NULL,'2026-03-25 13:11:21.779326','15 Rue Victor Hugo','','69001','France','Lyon'),(32,'2026-03-25 13:12:31.232763',NULL,'2026-03-25 13:12:31.232763',' Square Brassens','','91600','France','Savigny-sur-Orge'),(33,'2026-03-25 13:13:19.224673',NULL,'2026-03-25 13:13:19.224673','5 Rue des Lila',NULL,'75008','France','Paris'),(34,'2026-03-25 13:30:33.180304',NULL,'2026-03-25 13:30:33.180304','5 Rue des Lilas',NULL,'75008','France','Paris'),(35,'2026-03-25 13:34:19.644492',NULL,'2026-03-25 13:34:19.644492','5 Rue des Lilas',NULL,'75008','France','Paris'),(36,'2026-03-25 13:34:31.418993',NULL,'2026-03-25 13:34:31.418993','5 Rue des Lilas',NULL,'75008','France','Paris'),(37,'2026-03-25 13:34:48.289012',NULL,'2026-03-25 13:34:48.289012','11 Rue des Lilas',NULL,'75008','France','Paris'),(38,'2026-03-25 13:35:27.121631',NULL,'2026-03-25 13:35:27.121631','11 Rue des Lilas',NULL,'75008','France','Paris'),(39,'2026-03-25 13:37:35.983835',NULL,'2026-03-25 13:37:35.983835','11 Rue des Lilas',NULL,'75008','France','Paris'),(40,'2026-03-25 14:35:36.277961',NULL,'2026-03-25 14:35:36.277961','1 Rue des Lilas',NULL,'75008','France','Paris'),(41,'2026-03-25 14:35:56.230272',NULL,'2026-03-25 14:35:56.230272','5 Rue des Lilas',NULL,'75008','France','Paris'),(42,'2026-03-25 23:09:53.083424',NULL,'2026-03-25 23:09:53.083424','avenue de la liberte','','91600','France','Savigny-sur-Orge'),(43,'2026-03-25 23:10:08.395754',NULL,'2026-03-25 23:10:08.395754','7 avenue de la liberte','','91600','France','Savigny-sur-Orge'),(44,'2026-03-25 23:11:52.751570',NULL,'2026-03-25 23:11:52.751570','7 avenue de la liberte','','91600','France','Savigny-sur-Orge'),(45,'2026-03-25 23:13:24.809220',NULL,'2026-03-25 23:13:24.809220','7 avenue de la liberte','','91600','France','Savigny-sur-Orge'),(46,'2026-03-25 23:21:47.690060',NULL,'2026-03-25 23:21:47.690060','7 avenue de la liberte','','91600','France','Savigny-sur-Orge'),(47,'2026-03-25 23:22:03.148831',NULL,'2026-03-25 23:22:03.148831','7 avenue de la liberte','','91600','France','Savigny-sur-Orge'),(48,'2026-03-26 15:02:58.988253',NULL,'2026-03-26 15:02:58.988253','5 rue Victor','','92220','France','Bretigny sur Orge'),(49,'2026-03-26 15:04:31.011200',NULL,'2026-03-26 15:04:31.011200','5 Rue des Lilas',NULL,'75008','France','Paris'),(50,'2026-03-30 08:47:33.047072',NULL,'2026-03-30 08:47:33.047072','7 Rue des Lilas',NULL,'75008','France','Paris'),(51,'2026-04-23 22:34:51.242242',NULL,'2026-04-23 22:34:51.242242','1 rue du pardon','','91236','France','Sarmoise'),(52,'2026-04-24 12:55:50.670841',NULL,'2026-04-24 12:55:50.670841','5 rue de la joie','','91000','France','Evry'),(53,'2026-04-24 15:54:23.527508',NULL,'2026-04-24 15:54:23.527508','4 rue du tiers','','91220','France','Bretigny ');
/*!40000 ALTER TABLE `adresse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `detail` text COLLATE utf8mb4_general_ci,
  `entite` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `entite_id` bigint DEFAULT NULL,
  `id_entreprise` int DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `utilisateur_id` bigint DEFAULT NULL,
  `utilisateur_nom` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=488 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES (1,'READ','2026-04-22 22:36:58.379666','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(2,'READ','2026-04-22 22:36:58.365283','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(3,'READ','2026-04-22 22:36:58.391233','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(4,'READ','2026-04-22 22:36:58.471257','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(5,'READ','2026-04-22 22:36:58.485450','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(6,'READ','2026-04-22 22:36:58.487390','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(7,'READ','2026-04-22 22:36:58.487757','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(8,'READ','2026-04-22 22:36:58.489139','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(9,'READ','2026-04-22 22:36:58.490345','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(10,'READ','2026-04-22 22:36:58.504465','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(11,'READ','2026-04-22 22:36:58.503830','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(12,'READ','2026-04-22 22:36:58.504460','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(13,'READ','2026-04-22 22:36:58.505334','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(14,'READ','2026-04-22 22:36:58.507315','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(15,'READ','2026-04-22 22:36:58.523849','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(16,'READ','2026-04-22 22:36:58.527865','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(17,'READ','2026-04-22 22:36:58.525792','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(18,'READ','2026-04-22 22:36:58.527681','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(19,'READ','2026-04-22 22:36:58.543804','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(20,'READ','2026-04-22 22:36:58.544169','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(21,'READ','2026-04-22 22:36:58.546418','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(22,'READ','2026-04-22 22:36:58.546508','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(23,'READ','2026-04-22 22:36:58.551612','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(24,'READ','2026-04-22 22:36:58.567342','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(25,'READ','2026-04-22 22:36:58.579601','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(26,'READ','2026-04-22 22:36:58.583615','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(27,'READ','2026-04-22 22:36:58.583615','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(28,'READ','2026-04-22 22:36:58.593505','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(29,'READ','2026-04-22 22:36:58.595450','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(30,'READ','2026-04-22 22:36:58.594296','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(31,'READ','2026-04-22 22:36:58.599481','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(32,'READ','2026-04-22 22:36:58.601975','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(33,'READ','2026-04-22 22:36:58.611393','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(34,'READ','2026-04-22 22:36:58.611547','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(35,'READ','2026-04-22 22:36:58.619677','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(36,'READ','2026-04-22 22:36:58.623654','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(37,'READ','2026-04-22 22:36:58.623371','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(38,'READ','2026-04-22 22:36:58.623313','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(39,'READ','2026-04-22 22:36:58.627453','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(40,'READ','2026-04-22 22:36:58.631555','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(41,'READ','2026-04-22 22:36:58.635447','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(42,'READ','2026-04-22 22:36:58.641817','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(43,'READ','2026-04-22 22:36:58.651866','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(44,'READ','2026-04-22 22:36:58.658706','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(45,'READ','2026-04-22 22:36:58.661856','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(46,'READ','2026-04-22 22:36:58.661862','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(47,'READ','2026-04-22 22:36:58.794489','findById','produit',NULL,6,'5.49.2.95',NULL,'admin@macsecurite.fr'),(48,'READ','2026-04-23 12:27:59.867814','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(49,'READ','2026-04-23 12:27:59.879162','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(50,'READ','2026-04-23 12:27:59.900259','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(51,'READ','2026-04-23 12:27:59.904579','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(52,'READ','2026-04-23 12:27:59.908113','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(53,'READ','2026-04-23 12:27:59.915864','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(54,'READ','2026-04-23 12:27:59.920353','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(55,'READ','2026-04-23 12:27:59.921502','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(56,'READ','2026-04-23 12:28:00.013775','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(57,'READ','2026-04-23 12:28:00.019138','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(58,'READ','2026-04-23 12:28:00.022961','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(59,'READ','2026-04-23 12:28:00.039194','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(60,'READ','2026-04-23 12:28:00.041309','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(61,'READ','2026-04-23 12:28:00.044360','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(62,'READ','2026-04-23 12:28:00.046255','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(63,'READ','2026-04-23 12:28:00.055775','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(64,'READ','2026-04-23 12:28:00.055863','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(65,'READ','2026-04-23 12:28:00.058554','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(66,'READ','2026-04-23 12:28:00.074965','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(67,'READ','2026-04-23 12:28:00.082442','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(68,'READ','2026-04-23 12:28:00.082456','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(69,'READ','2026-04-23 12:28:00.082673','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(70,'READ','2026-04-23 12:28:00.082701','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(71,'READ','2026-04-23 12:28:00.084161','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(72,'READ','2026-04-23 12:28:00.084303','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(73,'READ','2026-04-23 12:28:00.084669','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(74,'READ','2026-04-23 12:28:00.084650','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(75,'READ','2026-04-23 12:28:00.094336','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(76,'READ','2026-04-23 12:28:00.102590','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(77,'READ','2026-04-23 12:28:00.102608','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(78,'READ','2026-04-23 12:28:00.104913','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(79,'READ','2026-04-23 12:28:00.109422','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(80,'READ','2026-04-23 12:28:00.109384','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(81,'READ','2026-04-23 12:28:00.109428','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(82,'READ','2026-04-23 12:28:00.109611','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(83,'READ','2026-04-23 12:28:00.110840','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(84,'READ','2026-04-23 12:28:00.112309','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(85,'READ','2026-04-23 12:28:00.112833','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(86,'READ','2026-04-23 12:28:00.112814','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(87,'READ','2026-04-23 12:28:00.117193','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(88,'READ','2026-04-23 12:28:00.119607','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(89,'READ','2026-04-23 12:28:00.119628','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(90,'READ','2026-04-23 12:28:00.120756','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(91,'READ','2026-04-23 12:28:00.120854','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(92,'READ','2026-04-23 12:28:00.122608','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(93,'READ','2026-04-23 12:28:00.139300','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(94,'READ','2026-04-23 12:28:00.140701','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(95,'READ','2026-04-23 12:57:00.720098','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(96,'READ','2026-04-23 12:57:00.730319','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(97,'READ','2026-04-23 12:57:00.730318','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(98,'READ','2026-04-23 12:57:00.727455','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(99,'READ','2026-04-23 12:57:00.728610','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(100,'READ','2026-04-23 12:57:00.769476','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(101,'READ','2026-04-23 12:57:00.811564','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(102,'READ','2026-04-23 12:57:00.834000','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(103,'READ','2026-04-23 12:57:00.838285','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(104,'READ','2026-04-23 12:57:00.842442','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(105,'READ','2026-04-23 12:57:00.847613','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(106,'READ','2026-04-23 12:57:00.853046','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(107,'READ','2026-04-23 12:57:00.854048','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(108,'READ','2026-04-23 12:57:00.855192','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(109,'READ','2026-04-23 12:57:00.857096','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(110,'READ','2026-04-23 12:57:00.860024','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(111,'READ','2026-04-23 12:57:00.859775','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(112,'READ','2026-04-23 12:57:00.868990','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(113,'READ','2026-04-23 12:57:00.877667','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(114,'READ','2026-04-23 12:57:00.879264','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(115,'READ','2026-04-23 12:57:00.883083','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(116,'READ','2026-04-23 12:57:00.884762','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(117,'READ','2026-04-23 12:57:00.885100','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(118,'READ','2026-04-23 12:57:00.885599','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(119,'READ','2026-04-23 12:57:00.887286','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(120,'READ','2026-04-23 12:57:00.890296','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(121,'READ','2026-04-23 12:57:00.900565','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(122,'READ','2026-04-23 12:57:00.903719','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(123,'READ','2026-04-23 12:57:00.908308','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(124,'READ','2026-04-23 12:57:00.911212','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(125,'READ','2026-04-23 12:57:00.917224','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(126,'READ','2026-04-23 12:57:00.919843','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(127,'READ','2026-04-23 12:57:00.919284','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(128,'READ','2026-04-23 12:57:00.921623','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(129,'READ','2026-04-23 12:57:00.922159','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(130,'READ','2026-04-23 12:57:00.922392','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(131,'READ','2026-04-23 12:57:00.926310','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(132,'READ','2026-04-23 12:57:00.926939','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(133,'READ','2026-04-23 12:57:00.927175','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(134,'READ','2026-04-23 12:57:00.927523','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(135,'READ','2026-04-23 12:57:00.929374','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(136,'READ','2026-04-23 12:57:00.929638','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(137,'READ','2026-04-23 12:57:00.931244','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(138,'READ','2026-04-23 12:57:00.942114','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(139,'READ','2026-04-23 12:57:00.942455','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(140,'READ','2026-04-23 12:57:00.942414','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(141,'READ','2026-04-23 12:57:00.945386','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(142,'READ','2026-04-23 14:27:23.153426','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(143,'READ','2026-04-23 14:27:23.167178','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(144,'READ','2026-04-23 14:27:23.153429','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(145,'READ','2026-04-23 14:27:23.179612','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(146,'READ','2026-04-23 14:27:23.272440','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(147,'READ','2026-04-23 14:27:23.275792','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(148,'READ','2026-04-23 14:27:23.278134','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(149,'READ','2026-04-23 14:27:23.278858','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(150,'READ','2026-04-23 14:27:23.282340','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(151,'READ','2026-04-23 14:27:23.291248','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(152,'READ','2026-04-23 14:27:23.293661','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(153,'READ','2026-04-23 14:27:23.298287','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(154,'READ','2026-04-23 14:27:23.298831','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(155,'READ','2026-04-23 14:27:23.301023','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(156,'READ','2026-04-23 14:27:23.300577','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(157,'READ','2026-04-23 14:27:23.300312','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(158,'READ','2026-04-23 14:27:23.301019','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(159,'READ','2026-04-23 14:27:23.311110','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(160,'READ','2026-04-23 14:27:23.316419','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(161,'READ','2026-04-23 14:27:23.316414','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(162,'READ','2026-04-23 14:27:23.316405','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(163,'READ','2026-04-23 14:27:23.316446','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(164,'READ','2026-04-23 14:27:23.326732','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(165,'READ','2026-04-23 14:27:23.327572','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(166,'READ','2026-04-23 14:27:23.328147','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(167,'READ','2026-04-23 14:27:23.328663','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(168,'READ','2026-04-23 14:27:23.328618','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(169,'READ','2026-04-23 14:27:23.328766','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(170,'READ','2026-04-23 14:27:23.332657','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(171,'READ','2026-04-23 14:27:23.332698','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(172,'READ','2026-04-23 14:27:23.332228','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(173,'READ','2026-04-23 14:27:23.333282','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(174,'READ','2026-04-23 14:27:23.333284','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(175,'READ','2026-04-23 14:27:23.334526','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(176,'READ','2026-04-23 14:27:23.335285','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(177,'READ','2026-04-23 14:27:23.335648','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(178,'READ','2026-04-23 14:27:23.337582','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(179,'READ','2026-04-23 14:27:23.340712','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(180,'READ','2026-04-23 14:27:23.341119','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(181,'READ','2026-04-23 14:27:23.343065','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(182,'READ','2026-04-23 14:27:23.343146','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(183,'READ','2026-04-23 14:27:23.343845','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(184,'READ','2026-04-23 14:27:23.347387','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(185,'READ','2026-04-23 14:27:23.365076','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(186,'READ','2026-04-23 14:27:23.366705','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(187,'READ','2026-04-23 14:27:23.369725','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(188,'READ','2026-04-23 14:27:23.379174','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(189,'READ','2026-04-23 14:28:21.404365','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(190,'READ','2026-04-23 14:28:21.404574','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(191,'READ','2026-04-23 14:28:21.404365','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(192,'READ','2026-04-23 14:28:21.408537','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(193,'READ','2026-04-23 14:28:21.414087','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(194,'READ','2026-04-23 14:28:21.550627','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(195,'READ','2026-04-23 14:28:21.550499','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(196,'READ','2026-04-23 14:28:21.550620','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(197,'READ','2026-04-23 14:28:21.550655','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(198,'READ','2026-04-23 14:28:21.552435','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(199,'READ','2026-04-23 14:28:21.562451','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(200,'READ','2026-04-23 14:28:21.565259','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(201,'READ','2026-04-23 14:28:21.565051','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(202,'READ','2026-04-23 14:28:21.566777','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(203,'READ','2026-04-23 14:28:21.576682','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(204,'READ','2026-04-23 14:28:21.582211','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(205,'READ','2026-04-23 14:28:21.583523','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(206,'READ','2026-04-23 14:28:21.587073','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(207,'READ','2026-04-23 14:28:21.591830','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(208,'READ','2026-04-23 14:28:21.595117','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(209,'READ','2026-04-23 14:28:21.595234','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(210,'READ','2026-04-23 14:28:21.595581','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(211,'READ','2026-04-23 14:28:21.595563','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(212,'READ','2026-04-23 14:28:21.596327','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(213,'READ','2026-04-23 14:28:21.596869','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(214,'READ','2026-04-23 14:28:21.618463','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(215,'READ','2026-04-23 14:28:21.611770','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(216,'READ','2026-04-23 14:28:21.627325','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(217,'READ','2026-04-23 14:28:21.627317','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(218,'READ','2026-04-23 14:28:21.625899','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(219,'READ','2026-04-23 14:28:21.628882','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(220,'READ','2026-04-23 14:28:21.643930','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(221,'READ','2026-04-23 14:28:21.649186','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(222,'READ','2026-04-23 14:28:21.651730','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(223,'READ','2026-04-23 14:28:21.649935','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(224,'READ','2026-04-23 14:28:21.656225','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(225,'READ','2026-04-23 14:28:21.655561','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(226,'READ','2026-04-23 14:28:21.663918','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(227,'READ','2026-04-23 14:28:21.664572','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(228,'READ','2026-04-23 14:28:21.673926','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(229,'READ','2026-04-23 14:28:21.673281','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(230,'READ','2026-04-23 14:28:21.674019','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(231,'READ','2026-04-23 14:28:21.674866','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(232,'READ','2026-04-23 14:28:21.668641','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(233,'READ','2026-04-23 14:28:21.670930','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(234,'READ','2026-04-23 14:28:21.680776','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(235,'READ','2026-04-23 14:28:21.697003','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(236,'READ','2026-04-23 14:28:28.734620','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(237,'READ','2026-04-23 14:28:28.749448','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(238,'READ','2026-04-23 14:28:28.749127','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(239,'READ','2026-04-23 14:28:28.749628','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(240,'READ','2026-04-23 14:28:28.749634','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(241,'READ','2026-04-23 14:28:28.749689','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(242,'READ','2026-04-23 14:28:28.757039','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(243,'READ','2026-04-23 14:28:28.834298','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(244,'READ','2026-04-23 14:28:28.899815','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(245,'READ','2026-04-23 14:28:28.900434','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(246,'READ','2026-04-23 14:28:28.900269','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(247,'READ','2026-04-23 14:28:28.901727','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(248,'READ','2026-04-23 14:28:28.901604','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(249,'READ','2026-04-23 14:28:28.901677','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(250,'READ','2026-04-23 14:28:28.903409','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(251,'READ','2026-04-23 14:28:28.904198','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(252,'READ','2026-04-23 14:28:28.905734','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(253,'READ','2026-04-23 14:28:28.905799','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(254,'READ','2026-04-23 14:28:28.906663','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(255,'READ','2026-04-23 14:28:28.909052','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(256,'READ','2026-04-23 14:28:28.917363','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(257,'READ','2026-04-23 14:28:28.919835','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(258,'READ','2026-04-23 14:28:28.920322','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(259,'READ','2026-04-23 14:28:28.920301','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(260,'READ','2026-04-23 14:28:28.921840','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(261,'READ','2026-04-23 14:28:28.921825','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(262,'READ','2026-04-23 14:28:28.922350','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(263,'READ','2026-04-23 14:28:28.922491','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(264,'READ','2026-04-23 14:28:28.923830','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(265,'READ','2026-04-23 14:28:28.924287','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(266,'READ','2026-04-23 14:28:28.925093','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(267,'READ','2026-04-23 14:28:28.925755','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(268,'READ','2026-04-23 14:28:28.925808','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(269,'READ','2026-04-23 14:28:28.926786','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(270,'READ','2026-04-23 14:28:28.926510','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(271,'READ','2026-04-23 14:28:28.927078','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(272,'READ','2026-04-23 14:28:28.929885','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(273,'READ','2026-04-23 14:28:28.929680','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(274,'READ','2026-04-23 14:28:28.930160','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(275,'READ','2026-04-23 14:28:28.930890','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(276,'READ','2026-04-23 14:28:28.934252','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(277,'READ','2026-04-23 14:28:28.935033','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(278,'READ','2026-04-23 14:28:28.935069','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(279,'READ','2026-04-23 14:28:28.935291','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(280,'READ','2026-04-23 14:28:28.935455','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(281,'READ','2026-04-23 14:28:29.036731','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(282,'READ','2026-04-23 14:28:29.060463','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(283,'READ','2026-04-23 14:36:54.726018','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(284,'READ','2026-04-23 14:36:54.728354','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(285,'READ','2026-04-23 14:36:54.736763','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(286,'READ','2026-04-23 14:36:54.738469','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(287,'READ','2026-04-23 14:36:54.765406','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(288,'READ','2026-04-23 14:36:54.841501','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(289,'READ','2026-04-23 14:36:54.856550','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(290,'READ','2026-04-23 14:36:54.865338','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(291,'READ','2026-04-23 14:36:54.866354','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(292,'READ','2026-04-23 14:36:54.871487','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(293,'READ','2026-04-23 14:36:54.871592','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(294,'READ','2026-04-23 14:36:54.871486','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(295,'READ','2026-04-23 14:36:54.872046','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(296,'READ','2026-04-23 14:36:54.877008','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(297,'READ','2026-04-23 14:36:54.877556','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(298,'READ','2026-04-23 14:36:54.877580','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(299,'READ','2026-04-23 14:36:54.878308','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(300,'READ','2026-04-23 14:36:54.878685','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(301,'READ','2026-04-23 14:36:54.878879','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(302,'READ','2026-04-23 14:36:54.879028','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(303,'READ','2026-04-23 14:36:54.888059','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(304,'READ','2026-04-23 14:36:54.892931','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(305,'READ','2026-04-23 14:36:54.896278','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(306,'READ','2026-04-23 14:36:54.900827','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(307,'READ','2026-04-23 14:36:54.905145','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(308,'READ','2026-04-23 14:36:54.905578','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(309,'READ','2026-04-23 14:36:54.905599','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(310,'READ','2026-04-23 14:36:54.906273','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(311,'READ','2026-04-23 14:36:54.906470','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(312,'READ','2026-04-23 14:36:54.906468','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(313,'READ','2026-04-23 14:36:54.907865','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(314,'READ','2026-04-23 14:36:54.908274','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(315,'READ','2026-04-23 14:36:54.909173','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(316,'READ','2026-04-23 14:36:54.910070','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(317,'READ','2026-04-23 14:36:54.910073','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(318,'READ','2026-04-23 14:36:54.910073','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(319,'READ','2026-04-23 14:36:54.912932','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(320,'READ','2026-04-23 14:36:54.913196','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(321,'READ','2026-04-23 14:36:54.915580','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(322,'READ','2026-04-23 14:36:54.915904','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(323,'READ','2026-04-23 14:36:54.915853','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(324,'READ','2026-04-23 14:36:54.918297','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(325,'READ','2026-04-23 14:36:54.919329','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(326,'READ','2026-04-23 14:36:54.927418','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(327,'READ','2026-04-23 14:36:54.928569','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(328,'READ','2026-04-23 14:36:54.932424','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(329,'READ','2026-04-23 14:36:54.938623','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(330,'READ','2026-04-23 14:37:53.742572','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(331,'READ','2026-04-23 14:37:53.744922','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(332,'READ','2026-04-23 14:37:53.746074','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(333,'READ','2026-04-23 14:37:53.746331','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(334,'READ','2026-04-23 14:37:53.751462','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(335,'READ','2026-04-23 14:37:53.752552','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(336,'READ','2026-04-23 14:37:53.753850','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(337,'READ','2026-04-23 14:37:53.754218','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(338,'READ','2026-04-23 14:37:53.763810','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(339,'READ','2026-04-23 14:37:53.887125','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(340,'READ','2026-04-23 14:37:53.893552','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(341,'READ','2026-04-23 14:37:53.896906','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(342,'READ','2026-04-23 14:37:53.901581','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(343,'READ','2026-04-23 14:37:53.902070','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(344,'READ','2026-04-23 14:37:53.902854','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(345,'READ','2026-04-23 14:37:53.902854','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(346,'READ','2026-04-23 14:37:53.907859','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(347,'READ','2026-04-23 14:37:53.912622','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(348,'READ','2026-04-23 14:37:53.912892','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(349,'READ','2026-04-23 14:37:53.914835','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(350,'READ','2026-04-23 14:37:53.915113','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(351,'READ','2026-04-23 14:37:53.915110','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(352,'READ','2026-04-23 14:37:53.915692','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(353,'READ','2026-04-23 14:37:53.916246','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(354,'READ','2026-04-23 14:37:53.916591','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(355,'READ','2026-04-23 14:37:53.917142','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(356,'READ','2026-04-23 14:37:53.917436','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(357,'READ','2026-04-23 14:37:53.918471','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(358,'READ','2026-04-23 14:37:53.919303','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(359,'READ','2026-04-23 14:37:53.921084','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(360,'READ','2026-04-23 14:37:53.921713','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(361,'READ','2026-04-23 14:37:53.921893','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(362,'READ','2026-04-23 14:37:53.925439','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(363,'READ','2026-04-23 14:37:53.925452','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(364,'READ','2026-04-23 14:37:53.925466','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(365,'READ','2026-04-23 14:37:53.927898','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(366,'READ','2026-04-23 14:37:53.929802','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(367,'READ','2026-04-23 14:37:53.935269','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(368,'READ','2026-04-23 14:37:53.937115','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(369,'READ','2026-04-23 14:37:53.937640','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(370,'READ','2026-04-23 14:37:53.937643','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(371,'READ','2026-04-23 14:37:53.937872','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(372,'READ','2026-04-23 14:37:53.943819','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(373,'READ','2026-04-23 14:37:53.944258','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(374,'READ','2026-04-23 14:37:53.947847','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(375,'READ','2026-04-23 14:37:53.953387','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(376,'READ','2026-04-23 14:37:54.088628','findById','produit',NULL,6,'176.191.72.189',NULL,'admin@macsecurite.fr'),(377,'READ','2026-04-23 21:59:06.114757','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(378,'READ','2026-04-23 21:59:06.114762','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(379,'READ','2026-04-23 21:59:06.114757','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(380,'READ','2026-04-23 21:59:06.133328','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(381,'READ','2026-04-23 21:59:06.137614','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(382,'READ','2026-04-23 21:59:06.143505','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(383,'READ','2026-04-23 21:59:06.243683','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(384,'READ','2026-04-23 21:59:06.256300','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(385,'READ','2026-04-23 21:59:06.257579','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(386,'READ','2026-04-23 21:59:06.257854','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(387,'READ','2026-04-23 21:59:06.259270','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(388,'READ','2026-04-23 21:59:06.263294','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(389,'READ','2026-04-23 21:59:06.269950','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(390,'READ','2026-04-23 21:59:06.270816','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(391,'READ','2026-04-23 21:59:06.270841','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(392,'READ','2026-04-23 21:59:06.278527','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(393,'READ','2026-04-23 21:59:06.294509','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(394,'READ','2026-04-23 21:59:06.294516','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(395,'READ','2026-04-23 21:59:06.294509','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(396,'READ','2026-04-23 21:59:06.294486','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(397,'READ','2026-04-23 21:59:06.294484','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(398,'READ','2026-04-23 21:59:06.313009','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(399,'READ','2026-04-23 21:59:06.313245','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(400,'READ','2026-04-23 21:59:06.316828','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(401,'READ','2026-04-23 21:59:06.316869','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(402,'READ','2026-04-23 21:59:06.316783','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(403,'READ','2026-04-23 21:59:06.318857','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(404,'READ','2026-04-23 21:59:06.318841','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(405,'READ','2026-04-23 21:59:06.324642','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(406,'READ','2026-04-23 21:59:06.324846','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(407,'READ','2026-04-23 21:59:06.328174','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(408,'READ','2026-04-23 21:59:06.329334','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(409,'READ','2026-04-23 21:59:06.335531','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(410,'READ','2026-04-23 21:59:06.337461','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(411,'READ','2026-04-23 21:59:06.339233','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(412,'READ','2026-04-23 21:59:06.341451','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(413,'READ','2026-04-23 21:59:06.342010','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(414,'READ','2026-04-23 21:59:06.343078','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(415,'READ','2026-04-23 21:59:06.348210','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(416,'READ','2026-04-23 21:59:06.349859','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(417,'READ','2026-04-23 21:59:06.351495','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(418,'READ','2026-04-23 21:59:06.355942','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(419,'READ','2026-04-23 21:59:06.357454','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(420,'READ','2026-04-23 21:59:06.357840','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(421,'READ','2026-04-23 21:59:06.359966','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(422,'READ','2026-04-23 21:59:06.374368','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(423,'READ','2026-04-23 21:59:06.426969','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(424,'READ','2026-04-23 21:59:12.586663','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(425,'READ','2026-04-23 21:59:12.586663','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(426,'READ','2026-04-23 21:59:12.586663','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(427,'READ','2026-04-23 21:59:12.591688','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(428,'READ','2026-04-23 21:59:12.605013','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(429,'READ','2026-04-23 21:59:12.613857','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(430,'READ','2026-04-23 21:59:12.716720','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(431,'READ','2026-04-23 21:59:12.725148','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(432,'READ','2026-04-23 21:59:12.726471','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(433,'READ','2026-04-23 21:59:12.731751','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(434,'READ','2026-04-23 21:59:12.733512','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(435,'READ','2026-04-23 21:59:12.737300','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(436,'READ','2026-04-23 21:59:12.738741','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(437,'READ','2026-04-23 21:59:12.739958','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(438,'READ','2026-04-23 21:59:12.740215','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(439,'READ','2026-04-23 21:59:12.740585','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(440,'READ','2026-04-23 21:59:12.740385','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(441,'READ','2026-04-23 21:59:12.743648','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(442,'READ','2026-04-23 21:59:12.744200','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(443,'READ','2026-04-23 21:59:12.745404','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(444,'READ','2026-04-23 21:59:12.753250','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(445,'READ','2026-04-23 21:59:12.757501','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(446,'READ','2026-04-23 21:59:12.760030','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(447,'READ','2026-04-23 21:59:12.764154','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(448,'READ','2026-04-23 21:59:12.764523','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(449,'READ','2026-04-23 21:59:12.764539','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(450,'READ','2026-04-23 21:59:12.765304','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(451,'READ','2026-04-23 21:59:12.765392','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(452,'READ','2026-04-23 21:59:12.765574','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(453,'READ','2026-04-23 21:59:12.765605','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(454,'READ','2026-04-23 21:59:12.770616','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(455,'READ','2026-04-23 21:59:12.773221','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(456,'READ','2026-04-23 21:59:12.773272','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(457,'READ','2026-04-23 21:59:12.777193','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(458,'READ','2026-04-23 21:59:12.779975','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(459,'READ','2026-04-23 21:59:12.780213','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(460,'READ','2026-04-23 21:59:12.780428','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(461,'READ','2026-04-23 21:59:12.787899','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(462,'READ','2026-04-23 21:59:12.787924','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(463,'READ','2026-04-23 21:59:12.789637','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(464,'READ','2026-04-23 21:59:12.790074','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(465,'READ','2026-04-23 21:59:12.790445','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(466,'READ','2026-04-23 21:59:12.790627','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(467,'READ','2026-04-23 21:59:12.792413','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(468,'READ','2026-04-23 21:59:12.800475','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(469,'READ','2026-04-23 21:59:12.811995','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(470,'READ','2026-04-23 21:59:12.957299','findById','produit',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(471,'CREATE_UPDATE','2026-04-23 22:34:51.314287','save','client',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(472,'CREATE_UPDATE','2026-04-24 12:55:50.690028','save','client',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(473,'CREATE_UPDATE','2026-04-24 15:54:23.574564','save','client',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(474,'ENTREE','2026-05-04 10:27:08.445567','entreeStock','stock',NULL,6,'89.87.173.217',NULL,'admin@macsecurite.fr'),(475,'SORTIE','2026-05-04 10:27:08.469124','sortieStock','stock',NULL,6,'89.87.173.217',NULL,'admin@macsecurite.fr'),(476,'CREATE_UPDATE','2026-05-04 10:27:08.471215','save','intervention',NULL,6,'89.87.173.217',NULL,'admin@macsecurite.fr'),(477,'CREATE_UPDATE','2026-05-04 10:30:57.958919','save','intervention',NULL,6,'89.87.173.217',NULL,'admin@macsecurite.fr'),(478,'ENTREE','2026-05-04 10:33:46.870654','entreeStock','stock',NULL,6,'89.87.173.217',NULL,'admin@macsecurite.fr'),(479,'ENTREE','2026-05-04 10:33:46.874758','entreeStock','stock',NULL,6,'89.87.173.217',NULL,'admin@macsecurite.fr'),(480,'SORTIE','2026-05-04 10:33:46.881957','sortieStock','stock',NULL,6,'89.87.173.217',NULL,'admin@macsecurite.fr'),(481,'SORTIE','2026-05-04 10:33:46.889207','sortieStock','stock',NULL,6,'89.87.173.217',NULL,'admin@macsecurite.fr'),(482,'CREATE_UPDATE','2026-05-04 10:33:46.891048','save','intervention',NULL,6,'89.87.173.217',NULL,'admin@macsecurite.fr'),(483,'ENTREE','2026-05-29 13:22:37.963274','entreeStock','stock',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(484,'ENTREE','2026-05-29 13:22:37.972106','entreeStock','stock',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(485,'SORTIE','2026-05-29 13:22:37.984430','sortieStock','stock',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(486,'SORTIE','2026-05-29 13:22:37.991110','sortieStock','stock',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr'),(487,'CREATE_UPDATE','2026-05-29 13:22:37.992691','save','intervention',NULL,6,'94.239.105.249',NULL,'admin@macsecurite.fr');
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKacatplu22q5d1andql2jbvjy7` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'2026-03-17 10:54:01.548660',6,'2026-03-17 10:54:01.548660','CAT001','Cameras de surveillance'),(3,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-CEN','Centrales'),(4,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-PRO','Prolongateurs de portee'),(5,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-DOU','Detecteurs d\'ouverture'),(6,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-DBG','Detecteurs de bris de glace'),(7,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-DMV','Detecteurs de mouvements'),(8,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-BTL','Boutons et telecommandes'),(9,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-CLA','Claviers'),(10,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-SIR','Sirenes'),(11,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-MOD','Modules d\'integration'),(12,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-REL','Relais'),(13,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-ALI','Unites d\'alimentation'),(14,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-INC','Detecteurs d\'incendie'),(15,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-FUI','Detecteurs de fuite'),(16,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-ECL','Interrupteurs d\'eclairage'),(17,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-AIR','Detecteurs de qualite de l\'air'),(18,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-PRI','Prises portables intelligentes'),(19,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-VID','Enregistreurs video'),(20,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-KIT','Kit Videosurveillance'),(21,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-BRO','Generateur de Brouillard'),(22,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-INT','Interphone Video IP'),(23,'2026-03-25 23:15:27.000000',6,'2026-03-25 23:15:27.000000','CAT-ACC','Controle d\'acces');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `num_tel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `prenom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_adresse` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKbfgjs3fem0hmjhvih80158x29` (`email`),
  UNIQUE KEY `UKmhe9ac6rtmg8wrt1f2bfoqpmd` (`id_adresse`),
  CONSTRAINT `FKpxwh4xi98rmanmlb1h88cohl9` FOREIGN KEY (`id_adresse`) REFERENCES `adresse` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,'2026-03-17 13:39:41.944636',6,'2026-03-30 08:47:33.389175','jean.dupont@email.fr','Dupont','0612345678',NULL,'Jean',50),(2,'2026-03-25 13:04:55.166064',6,'2026-03-25 13:04:55.166064','sophie.martin@email.fr','Martin','0698765432',NULL,'Sophie',24),(3,'2026-03-25 13:09:04.256092',6,'2026-03-25 13:09:04.256092','barrymdy@gmail.com','Mendy','0622515123',NULL,'Barekine',25),(18,'2026-03-26 15:02:59.342410',6,'2026-03-26 15:02:59.342410','oceanemarsi@gmail.com','Marsi','0632121415',NULL,'Oceane',48),(19,'2026-04-23 22:34:51.299238',6,'2026-04-23 22:34:51.299238','sakoba@gmail.com','BA','0613245658',NULL,'Sako',51),(20,'2026-04-24 12:55:50.681270',6,'2026-04-24 12:55:50.681270','pierremondi@gmail.com','Mondi','0623987541',NULL,'Pierre',52),(21,'2026-04-24 15:54:23.566328',6,'2026-04-24 15:54:23.566328','8NEhUXXqlG3lF6U9lbtdXDE+oSzn5udyXn9NflQto7g=','Taro','fePqE6CPRh3Cf1NVhSyHsQ==',NULL,'Jeannot',53);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commandefournisseur`
--

DROP TABLE IF EXISTS `commandefournisseur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commandefournisseur` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_commande` datetime(6) NOT NULL,
  `etat_commande` enum('ANNULEE','EN_PREPARATION','LIVREE','VALIDEE') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_fournisseur` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK9veqq1urtdixftdgo8m0nvvwt` (`code`),
  KEY `FKckkhmugx215nvo4o5cy6y3k1c` (`id_fournisseur`),
  CONSTRAINT `FKckkhmugx215nvo4o5cy6y3k1c` FOREIGN KEY (`id_fournisseur`) REFERENCES `fournisseur` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commandefournisseur`
--

LOCK TABLES `commandefournisseur` WRITE;
/*!40000 ALTER TABLE `commandefournisseur` DISABLE KEYS */;
INSERT INTO `commandefournisseur` VALUES (1,'2026-03-22 21:01:57.437859',6,'2026-03-22 21:01:57.437859','CF001','2026-03-22 21:01:57.408072','EN_PREPARATION',1),(2,'2026-03-23 16:58:49.997517',6,'2026-03-23 16:58:49.997517','CF002','2026-03-23 16:58:49.460487','EN_PREPARATION',1);
/*!40000 ALTER TABLE `commandefournisseur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dw_dim_client`
--

DROP TABLE IF EXISTS `dw_dim_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dw_dim_client` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `nom` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `prenom` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ville` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `pays` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_entreprise` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dw_dim_client`
--

LOCK TABLES `dw_dim_client` WRITE;
/*!40000 ALTER TABLE `dw_dim_client` DISABLE KEYS */;
INSERT INTO `dw_dim_client` VALUES (1,1,'Dupont','Jean','Paris','France',6),(2,2,'Martin','Sophie','Lyon','France',6),(3,3,'Mendy','Barekine','Savigny-sur-Orge','France',6),(4,18,'Marsi','Oceane','Bretigny sur Orge','France',6),(5,19,'BA','Sako','Sarmoise','France',6),(6,20,'Mondi','Pierre','Evry','France',6),(7,21,'Taro','Jeannot','Bretigny ','France',6);
/*!40000 ALTER TABLE `dw_dim_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dw_dim_produit`
--

DROP TABLE IF EXISTS `dw_dim_produit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dw_dim_produit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `produit_id` int NOT NULL,
  `code_produit` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `designation` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `categorie` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_entreprise` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dw_dim_produit`
--

LOCK TABLES `dw_dim_produit` WRITE;
/*!40000 ALTER TABLE `dw_dim_produit` DISABLE KEYS */;
INSERT INTO `dw_dim_produit` VALUES (1,1,'CAM001','Camera IP Exterieure HD','CAT001',6),(2,2,'CAM002','Camera IP Interieure HD','CAT001',6),(3,3,'CAM003','Camera Dome Anti-Vandalisme','CAT001',6),(4,4,'CAM004','Camera PTZ 360','CAT001',6),(5,5,'CAM005','Camera Thermique Exterieure','CAT001',6),(6,6,'CEN001','Centrale Alarme 8 Zones','CAT-CEN',6),(7,7,'CEN002','Centrale Alarme 16 Zones','CAT-CEN',6),(8,8,'CEN003','Centrale Alarme GSM 32 Zones','CAT-CEN',6),(9,9,'DOU001','Detecteur Ouverture Porte Magnetique','CAT-DOU',6),(10,10,'DOU002','Detecteur Ouverture Fenetre','CAT-DOU',6),(11,11,'DOU003','Detecteur Ouverture Sans Fil','CAT-DOU',6),(12,12,'DBG001','Detecteur Bris de Glace Filaire','CAT-DBG',6),(13,13,'DBG002','Detecteur Bris de Glace Sans Fil','CAT-DBG',6),(14,14,'DMV001','Detecteur PIR Interieur','CAT-DMV',6),(15,15,'DMV002','Detecteur PIR Exterieur','CAT-DMV',6),(16,16,'DMV003','Detecteur Double Technologie','CAT-DMV',6),(17,17,'DMV004','Detecteur PIR Sans Fil','CAT-DMV',6),(18,18,'BTL001','Telecommande 4 Boutons','CAT-BTL',6),(19,19,'BTL002','Bouton Panique','CAT-BTL',6),(20,20,'BTL003','Telecommande Bidirectionnelle','CAT-BTL',6),(21,21,'CLA001','Clavier LCD Filaire','CAT-CLA',6),(22,22,'CLA002','Clavier Tactile Sans Fil','CAT-CLA',6),(23,23,'CLA003','Clavier Biometrique','CAT-CLA',6),(24,24,'SIR001','Sirene Exterieure Flash LED','CAT-SIR',6),(25,25,'SIR002','Sirene Interieure 120dB','CAT-SIR',6),(26,26,'SIR003','Sir?ne Sans Fil Ext?rieure','CAT-SIR',6),(27,27,'ALI001','Alimentation 12V 2A','CAT-ALI',6),(28,28,'ALI002','Alimentation 12V 5A','CAT-ALI',6),(29,29,'ALI003','Batterie de Secours 7Ah','CAT-ALI',6),(30,30,'INC001','D?tecteur Fum?e Optique','CAT-INC',6),(31,31,'INC002','D?tecteur Chaleur','CAT-INC',6),(32,32,'INC003','D?tecteur CO2','CAT-INC',6),(33,33,'FUI001','D?tecteur Fuite Gaz','CAT-FUI',6),(34,34,'FUI002','D?tecteur Fuite Eau','CAT-FUI',6),(35,35,'VID001','Enregistreur NVR 8 Canaux','CAT-VID',6),(36,36,'VID002','Enregistreur DVR 16 Canaux','CAT-VID',6),(37,37,'VID003','Disque Dur 2To Surveillance','CAT-VID',6),(38,38,'KIT001','Kit 4 Cam?ras + NVR + Disque','CAT-KIT',6),(39,39,'KIT002','Kit Alarme Maison Complet','CAT-KIT',6),(40,40,'KIT003','Kit Vid?osurveillance Pro 8 Cam?ras','CAT-KIT',6),(41,41,'INT001','Interphone Vid?o 2 Fils','CAT-INT',6),(42,42,'INT002','Visiophone Connect? WiFi','CAT-INT',6),(43,43,'INT003','Portier Vid?o IP','CAT-INT',6),(44,44,'ACC001','Lecteur Badge RFID','CAT-ACC',6),(45,45,'ACC002','?lectroserrure 12V','CAT-ACC',6),(46,46,'ACC003','Contr?leur Acc?s 2 Portes','CAT-ACC',6),(47,47,'ACC004','Badge RFID (lot de 10)','CAT-ACC',6);
/*!40000 ALTER TABLE `dw_dim_produit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dw_dim_technicien`
--

DROP TABLE IF EXISTS `dw_dim_technicien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dw_dim_technicien` (
  `id` int NOT NULL AUTO_INCREMENT,
  `technicien_id` int NOT NULL,
  `nom` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `prenom` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fonction` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_entreprise` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dw_dim_technicien`
--

LOCK TABLES `dw_dim_technicien` WRITE;
/*!40000 ALTER TABLE `dw_dim_technicien` DISABLE KEYS */;
INSERT INTO `dw_dim_technicien` VALUES (1,8,'Admin','MacSpace','ADMIN',6),(2,9,'Macalou','Jean','TECHNICIEN',6),(3,11,'Tech','Cyril','TECHNICIEN',6),(4,12,'Mendez','Barry','TECHNICIEN',6);
/*!40000 ALTER TABLE `dw_dim_technicien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dw_dim_temps`
--

DROP TABLE IF EXISTS `dw_dim_temps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dw_dim_temps` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date_full` date NOT NULL,
  `jour` int NOT NULL,
  `mois` int NOT NULL,
  `trimestre` int NOT NULL,
  `annee` int NOT NULL,
  `semaine` int NOT NULL,
  `nom_mois` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `nom_jour` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dw_dim_temps`
--

LOCK TABLES `dw_dim_temps` WRITE;
/*!40000 ALTER TABLE `dw_dim_temps` DISABLE KEYS */;
INSERT INTO `dw_dim_temps` VALUES (1,'2026-03-17',17,3,1,2026,11,'March','Tuesday'),(2,'2026-03-22',22,3,1,2026,12,'March','Sunday'),(3,'2026-03-25',25,3,1,2026,12,'March','Wednesday'),(4,'2026-03-24',24,3,1,2026,12,'March','Tuesday'),(5,'2026-03-23',23,3,1,2026,12,'March','Monday'),(6,'2026-03-26',26,3,1,2026,12,'March','Thursday'),(7,'2026-03-30',30,3,1,2026,13,'March','Monday'),(8,'2026-04-01',1,4,2,2026,13,'April','Wednesday'),(16,'2026-01-01',1,1,1,2026,0,'January','Thursday'),(17,'2026-05-04',4,5,2,2026,18,'May','Monday'),(18,'2026-05-29',29,5,2,2026,21,'May','Friday');
/*!40000 ALTER TABLE `dw_dim_temps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dw_faits_interventions`
--

DROP TABLE IF EXISTS `dw_faits_interventions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dw_faits_interventions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date_id` int DEFAULT NULL,
  `technicien_id` int DEFAULT NULL,
  `etat` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nb_produits` int DEFAULT '0',
  `id_entreprise` int DEFAULT NULL,
  `intervention_id` int NOT NULL,
  `date_intervention` date DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dw_faits_interventions`
--

LOCK TABLES `dw_faits_interventions` WRITE;
/*!40000 ALTER TABLE `dw_faits_interventions` DISABLE KEYS */;
INSERT INTO `dw_faits_interventions` VALUES (17,1,3,'EN_ATTENTE',0,6,1,'2026-03-17','2026-05-29 14:07:38'),(18,1,2,'TERMINEE',3,6,2,'2026-03-17','2026-05-29 14:07:38'),(19,2,2,'TERMINEE',2,6,3,'2026-03-22','2026-05-29 14:07:38'),(20,3,1,'ANNULEE',0,6,6,'2026-03-25','2026-05-29 14:07:38'),(21,4,1,'TERMINEE',1,6,7,'2026-03-24','2026-05-29 14:07:38'),(22,5,3,'TERMINEE',0,6,8,'2026-03-23','2026-05-29 14:07:38'),(23,6,3,'TERMINEE',0,6,12,'2026-03-26','2026-05-29 14:07:38'),(24,6,4,'TERMINEE',1,6,13,'2026-03-26','2026-05-29 14:07:38'),(25,6,4,'TERMINEE',2,6,14,'2026-03-26','2026-05-29 14:07:38'),(26,7,4,'EN_COURS',3,6,15,'2026-03-30','2026-05-29 14:07:38'),(27,8,2,'EN_ATTENTE',0,6,16,'2026-04-01','2026-05-29 14:07:38'),(28,17,3,'EN_ATTENTE',3,6,17,'2026-05-04','2026-05-29 14:07:38');
/*!40000 ALTER TABLE `dw_faits_interventions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dw_faits_stock`
--

DROP TABLE IF EXISTS `dw_faits_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dw_faits_stock` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date_id` int DEFAULT NULL,
  `produit_id` int DEFAULT NULL,
  `type_mvt` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `quantite` decimal(10,2) DEFAULT NULL,
  `source_mvt` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_entreprise` int DEFAULT NULL,
  `mvt_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dw_faits_stock`
--

LOCK TABLES `dw_faits_stock` WRITE;
/*!40000 ALTER TABLE `dw_faits_stock` DISABLE KEYS */;
INSERT INTO `dw_faits_stock` VALUES (1,16,1,'ENTREE',15.00,'COMMANDE_FOURNISSEUR',6,59,'2026-05-02 14:43:31'),(2,16,2,'ENTREE',20.00,'COMMANDE_FOURNISSEUR',6,60,'2026-05-02 14:43:31'),(3,16,3,'ENTREE',10.00,'COMMANDE_FOURNISSEUR',6,61,'2026-05-02 14:43:31'),(4,16,4,'ENTREE',5.00,'COMMANDE_FOURNISSEUR',6,62,'2026-05-02 14:43:31'),(5,16,5,'ENTREE',3.00,'COMMANDE_FOURNISSEUR',6,63,'2026-05-02 14:43:31'),(6,16,6,'ENTREE',10.00,'COMMANDE_FOURNISSEUR',6,64,'2026-05-02 14:43:31'),(7,16,7,'ENTREE',8.00,'COMMANDE_FOURNISSEUR',6,65,'2026-05-02 14:43:31'),(8,16,8,'ENTREE',5.00,'COMMANDE_FOURNISSEUR',6,66,'2026-05-02 14:43:31'),(9,16,9,'ENTREE',50.00,'COMMANDE_FOURNISSEUR',6,67,'2026-05-02 14:43:31'),(10,16,10,'ENTREE',50.00,'COMMANDE_FOURNISSEUR',6,68,'2026-05-02 14:43:31'),(11,16,11,'ENTREE',30.00,'COMMANDE_FOURNISSEUR',6,69,'2026-05-02 14:43:31'),(12,16,12,'ENTREE',20.00,'COMMANDE_FOURNISSEUR',6,70,'2026-05-02 14:43:31'),(13,16,13,'ENTREE',15.00,'COMMANDE_FOURNISSEUR',6,71,'2026-05-02 14:43:31'),(14,16,14,'ENTREE',40.00,'COMMANDE_FOURNISSEUR',6,72,'2026-05-02 14:43:31'),(15,16,15,'ENTREE',30.00,'COMMANDE_FOURNISSEUR',6,73,'2026-05-02 14:43:31'),(16,16,16,'ENTREE',20.00,'COMMANDE_FOURNISSEUR',6,74,'2026-05-02 14:43:31'),(17,16,17,'ENTREE',25.00,'COMMANDE_FOURNISSEUR',6,75,'2026-05-02 14:43:31'),(18,16,18,'ENTREE',30.00,'COMMANDE_FOURNISSEUR',6,76,'2026-05-02 14:43:31'),(19,16,19,'ENTREE',25.00,'COMMANDE_FOURNISSEUR',6,77,'2026-05-02 14:43:31'),(20,16,20,'ENTREE',20.00,'COMMANDE_FOURNISSEUR',6,78,'2026-05-02 14:43:31'),(21,16,21,'ENTREE',15.00,'COMMANDE_FOURNISSEUR',6,79,'2026-05-02 14:43:31'),(22,16,22,'ENTREE',10.00,'COMMANDE_FOURNISSEUR',6,80,'2026-05-02 14:43:31'),(23,16,23,'ENTREE',5.00,'COMMANDE_FOURNISSEUR',6,81,'2026-05-02 14:43:31'),(24,16,24,'ENTREE',20.00,'COMMANDE_FOURNISSEUR',6,82,'2026-05-02 14:43:31'),(25,16,25,'ENTREE',25.00,'COMMANDE_FOURNISSEUR',6,83,'2026-05-02 14:43:31'),(26,16,26,'ENTREE',15.00,'COMMANDE_FOURNISSEUR',6,84,'2026-05-02 14:43:31'),(27,16,27,'ENTREE',40.00,'COMMANDE_FOURNISSEUR',6,85,'2026-05-02 14:43:31'),(28,16,28,'ENTREE',30.00,'COMMANDE_FOURNISSEUR',6,86,'2026-05-02 14:43:31'),(29,16,29,'ENTREE',20.00,'COMMANDE_FOURNISSEUR',6,87,'2026-05-02 14:43:31'),(30,16,30,'ENTREE',30.00,'COMMANDE_FOURNISSEUR',6,88,'2026-05-02 14:43:31'),(31,16,31,'ENTREE',25.00,'COMMANDE_FOURNISSEUR',6,89,'2026-05-02 14:43:31'),(32,16,32,'ENTREE',20.00,'COMMANDE_FOURNISSEUR',6,90,'2026-05-02 14:43:31'),(33,16,33,'ENTREE',20.00,'COMMANDE_FOURNISSEUR',6,91,'2026-05-02 14:43:31'),(34,16,34,'ENTREE',25.00,'COMMANDE_FOURNISSEUR',6,92,'2026-05-02 14:43:31'),(35,16,35,'ENTREE',10.00,'COMMANDE_FOURNISSEUR',6,93,'2026-05-02 14:43:31'),(36,16,36,'ENTREE',8.00,'COMMANDE_FOURNISSEUR',6,94,'2026-05-02 14:43:31'),(37,16,37,'ENTREE',20.00,'COMMANDE_FOURNISSEUR',6,95,'2026-05-02 14:43:31'),(38,16,38,'ENTREE',5.00,'COMMANDE_FOURNISSEUR',6,96,'2026-05-02 14:43:31'),(39,16,39,'ENTREE',8.00,'COMMANDE_FOURNISSEUR',6,97,'2026-05-02 14:43:31'),(40,16,40,'ENTREE',3.00,'COMMANDE_FOURNISSEUR',6,98,'2026-05-02 14:43:31'),(41,16,41,'ENTREE',10.00,'COMMANDE_FOURNISSEUR',6,99,'2026-05-02 14:43:31'),(42,16,42,'ENTREE',8.00,'COMMANDE_FOURNISSEUR',6,100,'2026-05-02 14:43:31'),(43,16,43,'ENTREE',6.00,'COMMANDE_FOURNISSEUR',6,101,'2026-05-02 14:43:31'),(44,16,44,'ENTREE',20.00,'COMMANDE_FOURNISSEUR',6,102,'2026-05-02 14:43:31'),(45,16,45,'ENTREE',15.00,'COMMANDE_FOURNISSEUR',6,103,'2026-05-02 14:43:31'),(46,16,46,'ENTREE',8.00,'COMMANDE_FOURNISSEUR',6,104,'2026-05-02 14:43:31'),(47,16,47,'ENTREE',100.00,'COMMANDE_FOURNISSEUR',6,105,'2026-05-02 14:43:31'),(48,7,7,'SORTIE',-1.00,'INTERVENTION',6,106,'2026-05-02 14:43:31'),(49,7,7,'SORTIE',-2.00,'INTERVENTION',6,107,'2026-05-02 14:43:31'),(50,7,7,'SORTIE',-1.00,'INTERVENTION',6,108,'2026-05-02 14:43:31'),(51,7,1,'SORTIE',-2.00,'INTERVENTION',6,109,'2026-05-02 14:43:31'),(52,7,1,'ENTREE',2.00,'INTERVENTION',6,110,'2026-05-02 14:43:31'),(53,7,1,'ENTREE',2.00,'INTERVENTION',6,111,'2026-05-02 14:43:31'),(54,7,1,'ENTREE',2.00,'INTERVENTION',6,112,'2026-05-02 14:43:31'),(55,7,1,'ENTREE',2.00,'INTERVENTION',6,113,'2026-05-02 14:43:31'),(56,7,1,'SORTIE',-1.00,'INTERVENTION',6,114,'2026-05-02 14:43:31'),(57,7,9,'SORTIE',-1.00,'INTERVENTION',6,115,'2026-05-02 14:43:31'),(58,7,3,'SORTIE',-2.00,'INTERVENTION',6,116,'2026-05-02 14:43:31'),(59,7,9,'ENTREE',1.00,'INTERVENTION',6,117,'2026-05-02 14:43:31'),(60,7,3,'ENTREE',2.00,'INTERVENTION',6,118,'2026-05-02 14:43:31'),(61,7,9,'SORTIE',-1.00,'INTERVENTION',6,119,'2026-05-02 14:43:31'),(62,7,7,'ENTREE',1.00,'INTERVENTION',6,120,'2026-05-02 14:43:31'),(63,7,7,'ENTREE',2.00,'INTERVENTION',6,121,'2026-05-02 14:43:31'),(64,7,7,'ENTREE',1.00,'INTERVENTION',6,122,'2026-05-02 14:43:31'),(65,7,7,'SORTIE',-2.00,'INTERVENTION',6,123,'2026-05-02 14:43:31'),(66,7,1,'ENTREE',1.00,'INTERVENTION',6,124,'2026-05-02 14:43:31'),(67,7,9,'ENTREE',1.00,'INTERVENTION',6,125,'2026-05-02 14:43:31'),(68,7,9,'SORTIE',-1.00,'INTERVENTION',6,126,'2026-05-02 14:43:31'),(69,7,4,'SORTIE',-1.00,'INTERVENTION',6,127,'2026-05-02 14:43:31'),(70,7,24,'SORTIE',-1.00,'INTERVENTION',6,128,'2026-05-02 14:43:31'),(71,7,7,'ENTREE',2.00,'INTERVENTION',6,129,'2026-05-02 14:43:31'),(72,7,7,'SORTIE',-2.00,'INTERVENTION',6,130,'2026-05-02 14:43:31'),(73,7,9,'SORTIE',-1.00,'INTERVENTION',6,131,'2026-05-02 14:43:31'),(74,7,7,'ENTREE',2.00,'INTERVENTION',6,132,'2026-05-02 14:43:31'),(75,7,9,'ENTREE',1.00,'INTERVENTION',6,133,'2026-05-02 14:43:31'),(76,7,7,'SORTIE',-2.00,'INTERVENTION',6,134,'2026-05-02 14:43:31'),(77,7,9,'SORTIE',-1.00,'INTERVENTION',6,135,'2026-05-02 14:43:31'),(78,7,8,'SORTIE',-1.00,'INTERVENTION',6,136,'2026-05-02 14:43:31'),(79,7,14,'SORTIE',-1.00,'INTERVENTION',6,137,'2026-05-02 14:43:31'),(80,7,42,'SORTIE',-1.00,'INTERVENTION',6,138,'2026-05-02 14:43:31'),(81,7,14,'ENTREE',1.00,'INTERVENTION',6,139,'2026-05-02 14:43:31'),(82,7,42,'ENTREE',1.00,'INTERVENTION',6,140,'2026-05-02 14:43:31'),(83,7,14,'SORTIE',-1.00,'INTERVENTION',6,141,'2026-05-02 14:43:31'),(84,7,42,'SORTIE',-1.00,'INTERVENTION',6,142,'2026-05-02 14:43:31'),(85,7,14,'ENTREE',1.00,'INTERVENTION',6,143,'2026-05-02 14:43:31'),(86,7,42,'ENTREE',1.00,'INTERVENTION',6,144,'2026-05-02 14:43:31'),(87,7,14,'SORTIE',-1.00,'INTERVENTION',6,145,'2026-05-02 14:43:31'),(88,7,14,'ENTREE',1.00,'INTERVENTION',6,146,'2026-05-02 14:43:31'),(89,7,14,'SORTIE',-1.00,'INTERVENTION',6,147,'2026-05-02 14:43:31'),(90,7,14,'SORTIE',-1.00,'INTERVENTION',6,148,'2026-05-02 14:43:31'),(91,7,14,'ENTREE',1.00,'INTERVENTION',6,149,'2026-05-02 14:43:31'),(92,7,14,'ENTREE',1.00,'INTERVENTION',6,150,'2026-05-02 14:43:31'),(93,7,14,'SORTIE',-1.00,'INTERVENTION',6,151,'2026-05-02 14:43:31'),(94,7,7,'ENTREE',2.00,'INTERVENTION',6,152,'2026-05-02 14:43:31'),(95,7,9,'ENTREE',1.00,'INTERVENTION',6,153,'2026-05-02 14:43:31'),(96,7,7,'SORTIE',-2.00,'INTERVENTION',6,154,'2026-05-02 14:43:31'),(97,7,9,'SORTIE',-1.00,'INTERVENTION',6,155,'2026-05-02 14:43:31'),(98,7,14,'SORTIE',-1.00,'INTERVENTION',6,156,'2026-05-02 14:43:31'),(99,7,7,'ENTREE',2.00,'INTERVENTION',6,157,'2026-05-02 14:43:31'),(100,7,9,'ENTREE',1.00,'INTERVENTION',6,158,'2026-05-02 14:43:31'),(101,7,14,'ENTREE',1.00,'INTERVENTION',6,159,'2026-05-02 14:43:31'),(102,7,7,'SORTIE',-2.00,'INTERVENTION',6,160,'2026-05-02 14:43:31'),(103,7,9,'SORTIE',-1.00,'INTERVENTION',6,161,'2026-05-02 14:43:31'),(104,7,7,'ENTREE',2.00,'INTERVENTION',6,162,'2026-05-02 14:43:31'),(105,7,9,'ENTREE',1.00,'INTERVENTION',6,163,'2026-05-02 14:43:31'),(106,7,7,'SORTIE',-2.00,'INTERVENTION',6,164,'2026-05-02 14:43:31'),(107,7,9,'SORTIE',-1.00,'INTERVENTION',6,165,'2026-05-02 14:43:31'),(108,7,6,'SORTIE',-1.00,'INTERVENTION',6,166,'2026-05-02 14:43:31'),(109,7,15,'SORTIE',-1.00,'INTERVENTION',6,167,'2026-05-02 14:43:31'),(110,7,2,'SORTIE',-1.00,'INTERVENTION',6,168,'2026-05-02 14:43:31'),(111,7,15,'ENTREE',1.00,'INTERVENTION',6,169,'2026-05-02 14:43:31'),(112,7,2,'ENTREE',1.00,'INTERVENTION',6,170,'2026-05-02 14:43:31'),(113,7,15,'SORTIE',-1.00,'INTERVENTION',6,171,'2026-05-02 14:43:31'),(114,7,7,'ENTREE',2.00,'INTERVENTION',6,172,'2026-05-02 14:43:31'),(115,7,9,'ENTREE',1.00,'INTERVENTION',6,173,'2026-05-02 14:43:31'),(116,7,6,'ENTREE',1.00,'INTERVENTION',6,174,'2026-05-02 14:43:31'),(117,7,7,'SORTIE',-2.00,'INTERVENTION',6,175,'2026-05-02 14:43:31'),(118,7,6,'SORTIE',-1.00,'INTERVENTION',6,176,'2026-05-02 14:43:31'),(119,7,1,'SORTIE',-1.00,'INTERVENTION',6,177,'2026-05-02 14:43:31'),(120,7,18,'SORTIE',-1.00,'INTERVENTION',6,178,'2026-05-02 14:43:31'),(121,7,24,'SORTIE',-1.00,'INTERVENTION',6,179,'2026-05-02 14:43:31'),(122,7,9,'ENTREE',1.00,'INTERVENTION',6,180,'2026-05-02 14:43:31'),(123,7,4,'ENTREE',1.00,'INTERVENTION',6,181,'2026-05-02 14:43:31'),(124,7,24,'ENTREE',1.00,'INTERVENTION',6,182,'2026-05-02 14:43:31'),(125,7,9,'SORTIE',-1.00,'INTERVENTION',6,183,'2026-05-02 14:43:31'),(126,7,8,'SORTIE',-1.00,'INTERVENTION',6,184,'2026-05-02 14:43:31'),(127,7,24,'SORTIE',-1.00,'INTERVENTION',6,185,'2026-05-02 14:43:31'),(128,7,9,'ENTREE',1.00,'INTERVENTION',6,186,'2026-05-02 14:43:31'),(129,7,8,'ENTREE',1.00,'INTERVENTION',6,187,'2026-05-02 14:43:31'),(130,7,24,'ENTREE',1.00,'INTERVENTION',6,188,'2026-05-02 14:43:31'),(131,7,9,'SORTIE',-1.00,'INTERVENTION',6,189,'2026-05-02 14:43:31'),(132,7,7,'SORTIE',-1.00,'INTERVENTION',6,190,'2026-05-02 14:43:31'),(133,7,24,'SORTIE',-1.00,'INTERVENTION',6,191,'2026-05-02 14:43:31'),(134,7,9,'ENTREE',1.00,'INTERVENTION',6,192,'2026-05-02 14:43:31'),(135,7,7,'ENTREE',1.00,'INTERVENTION',6,193,'2026-05-02 14:43:31'),(136,7,24,'ENTREE',1.00,'INTERVENTION',6,194,'2026-05-02 14:43:31'),(137,7,9,'SORTIE',-1.00,'INTERVENTION',6,195,'2026-05-02 14:43:31'),(138,7,7,'SORTIE',-1.00,'INTERVENTION',6,196,'2026-05-02 14:43:31'),(139,7,24,'SORTIE',-2.00,'INTERVENTION',6,197,'2026-05-02 14:43:31'),(140,8,9,'ENTREE',1.00,'INTERVENTION',6,198,'2026-05-02 14:43:31'),(141,8,7,'ENTREE',1.00,'INTERVENTION',6,199,'2026-05-02 14:43:31'),(142,8,24,'ENTREE',2.00,'INTERVENTION',6,200,'2026-05-02 14:43:31'),(143,8,9,'SORTIE',-1.00,'INTERVENTION',6,201,'2026-05-02 14:43:31'),(144,8,7,'SORTIE',-1.00,'INTERVENTION',6,202,'2026-05-02 14:43:31'),(145,8,24,'SORTIE',-2.00,'INTERVENTION',6,203,'2026-05-02 14:43:31'),(146,8,7,'ENTREE',2.00,'INTERVENTION',6,204,'2026-05-02 14:43:31'),(147,8,6,'ENTREE',1.00,'INTERVENTION',6,205,'2026-05-02 14:43:31'),(148,8,7,'SORTIE',-2.00,'INTERVENTION',6,206,'2026-05-02 14:43:31'),(149,8,6,'SORTIE',-1.00,'INTERVENTION',6,207,'2026-05-02 14:43:31'),(150,8,15,'ENTREE',1.00,'INTERVENTION',6,208,'2026-05-02 14:43:31'),(151,8,15,'SORTIE',-1.00,'INTERVENTION',6,209,'2026-05-02 14:43:31'),(152,8,6,'SORTIE',-1.00,'INTERVENTION',6,210,'2026-05-02 14:43:31'),(256,17,14,'ENTREE',1.00,'INTERVENTION',6,211,'2026-05-29 13:13:43'),(257,17,14,'SORTIE',-1.00,'INTERVENTION',6,212,'2026-05-29 13:13:43'),(258,17,15,'ENTREE',1.00,'INTERVENTION',6,213,'2026-05-29 13:13:43'),(259,17,6,'ENTREE',1.00,'INTERVENTION',6,214,'2026-05-29 13:13:43'),(260,17,15,'SORTIE',-1.00,'INTERVENTION',6,215,'2026-05-29 13:13:43'),(261,17,6,'SORTIE',-1.00,'INTERVENTION',6,216,'2026-05-29 13:13:43'),(263,18,15,'ENTREE',1.00,'INTERVENTION',6,217,'2026-05-29 13:22:48'),(264,18,6,'ENTREE',1.00,'INTERVENTION',6,218,'2026-05-29 13:22:48'),(265,18,15,'SORTIE',-1.00,'INTERVENTION',6,219,'2026-05-29 13:22:48'),(266,18,6,'SORTIE',-1.00,'INTERVENTION',6,220,'2026-05-29 13:22:48');
/*!40000 ALTER TABLE `dw_faits_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entreprise`
--

DROP TABLE IF EXISTS `entreprise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entreprise` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `code_fiscal` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `num_tel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `site_web` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_adresse` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK1qru4hbxc17dc7hjxtyfembe1` (`code_fiscal`),
  UNIQUE KEY `UKikbn4jhj98xcluw6k7c36iv6w` (`email`),
  UNIQUE KEY `UKb50fiifxgo1hpc2wggi93tupt` (`id_adresse`),
  CONSTRAINT `FKdqh78b528eiv67b0g39b787bo` FOREIGN KEY (`id_adresse`) REFERENCES `adresse` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entreprise`
--

LOCK TABLES `entreprise` WRITE;
/*!40000 ALTER TABLE `entreprise` DISABLE KEYS */;
INSERT INTO `entreprise` VALUES (6,'2026-03-16 11:43:00.936941',NULL,'2026-03-16 11:43:00.936941','MACSEC2024','Soci?t? de s?curit?','contact@macsecurite.fr','Mac S?curit?','0612345678',NULL,'www.macsecurite.fr',13);
/*!40000 ALTER TABLE `entreprise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fournisseur`
--

DROP TABLE IF EXISTS `fournisseur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fournisseur` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `num_tel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `prenom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_adresse` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKjbgq4kotuud6g548jycag5qwp` (`email`),
  UNIQUE KEY `UKgmjfn6x4sin07u4j4od4s2rqd` (`id_adresse`),
  CONSTRAINT `FKl46vp1es7bly9rpu97bt4ah55` FOREIGN KEY (`id_adresse`) REFERENCES `adresse` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseur`
--

LOCK TABLES `fournisseur` WRITE;
/*!40000 ALTER TABLE `fournisseur` DISABLE KEYS */;
INSERT INTO `fournisseur` VALUES (1,'2026-03-17 12:51:31.714197',6,'2026-03-17 12:51:31.714197','contact@securtech.fr','SecurTech','0123456789',NULL,'Fournisseur',21),(2,'2026-03-25 23:09:53.694352',6,'2026-03-25 23:22:03.175660','harry@fournisseur.com','Ideal Camera','0613645223',NULL,'Harry',47);
/*!40000 ALTER TABLE `fournisseur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interventionclient`
--

DROP TABLE IF EXISTS `interventionclient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interventionclient` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_intervention` datetime(6) NOT NULL,
  `etat_intervention` enum('ANNULEE','EN_ATTENTE','EN_COURS','TERMINEE') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_client` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK5fhv55n1f0ij8b79rrhuuhi7l` (`code`),
  KEY `FKfbbqs6anhxp5ba6fxxrkwur6n` (`id_client`),
  CONSTRAINT `FKfbbqs6anhxp5ba6fxxrkwur6n` FOREIGN KEY (`id_client`) REFERENCES `client` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interventionclient`
--

LOCK TABLES `interventionclient` WRITE;
/*!40000 ALTER TABLE `interventionclient` DISABLE KEYS */;
INSERT INTO `interventionclient` VALUES (1,'2026-03-22 20:59:10.498658',6,'2026-03-22 20:59:10.498658','INTCLI001','2026-03-22 20:59:09.941974','EN_ATTENTE',1),(2,'2026-03-23 18:06:15.792473',6,'2026-03-23 18:06:15.792473','INTCLI002','2026-03-23 18:06:15.542670','EN_ATTENTE',1),(3,'2026-03-23 18:15:52.521551',6,'2026-03-23 18:15:52.521551','INTCLI003','2026-03-23 18:15:52.451852','EN_ATTENTE',1);
/*!40000 ALTER TABLE `interventionclient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interventions`
--

DROP TABLE IF EXISTS `interventions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interventions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_intervention` datetime(6) NOT NULL,
  `etat_intervention` enum('ANNULEE','EN_ATTENTE','EN_COURS','TERMINEE') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `problematique` text COLLATE utf8mb4_general_ci,
  `id_technicien` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKo1lb74re16v4jik4fm64bkdy9` (`code`),
  KEY `FK4x0tvpmednsqh66qcdr6r58dt` (`id_technicien`),
  CONSTRAINT `FK4x0tvpmednsqh66qcdr6r58dt` FOREIGN KEY (`id_technicien`) REFERENCES `utilisateur` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interventions`
--

LOCK TABLES `interventions` WRITE;
/*!40000 ALTER TABLE `interventions` DISABLE KEYS */;
INSERT INTO `interventions` VALUES (1,'2026-03-17 14:29:18.235046',6,'2026-04-01 14:20:14.820294','INT001','2026-03-17 00:00:00.000000','EN_ATTENTE','Installation camera',11),(2,'2026-03-17 14:37:37.845587',6,'2026-04-01 14:20:30.595640','INT002','2026-03-17 00:00:00.000000','TERMINEE','Maintenance systeme alarme',9),(3,'2026-03-22 22:33:40.790844',6,'2026-04-01 14:20:48.815265','INT003','2026-03-22 00:00:00.000000','TERMINEE','Installation systeme de securite complet',9),(6,'2026-03-25 22:37:08.353394',6,'2026-03-25 22:50:28.275498','PRO111','2026-03-25 00:00:00.000000','ANNULEE','',8),(7,'2026-03-25 22:37:56.372157',6,'2026-03-30 13:42:29.165314','PRO12','2026-03-24 00:00:00.000000','TERMINEE','Installation chez Mr Dupont',8),(8,'2026-03-25 22:39:03.058842',6,'2026-04-01 14:22:11.146640','PRO13','2026-03-23 00:00:00.000000','TERMINEE','Rien a signaler tout est fait nickel',11),(12,'2026-03-26 09:23:39.875541',6,'2026-03-26 16:52:46.222606','PRO15','2026-03-26 00:00:00.000000','TERMINEE','Installer alarme dans le garage',11),(13,'2026-03-26 15:59:25.097282',6,'2026-05-04 10:27:08.481155','PRO16','2026-03-26 00:00:00.000000','TERMINEE','Changement du detecteur compliquer',12),(14,'2026-03-26 16:52:17.101037',6,'2026-05-29 13:22:37.995904','PRO17','2026-03-26 00:00:00.000000','TERMINEE','RAS tout est ok',12),(15,'2026-03-30 11:44:37.137717',6,'2026-03-30 14:03:24.095627','INT0123','2026-03-30 00:00:00.000000','EN_COURS','',12),(16,'2026-04-01 14:19:48.024385',6,'2026-04-01 14:19:48.024385','INT026','2026-04-01 00:00:00.000000','EN_ATTENTE','Intervention a Roissy',9),(17,'2026-05-04 10:30:57.948868',6,'2026-05-04 10:30:57.948868','INT0032','2026-05-04 00:00:00.000000','EN_ATTENTE','Installation en hauteur',11);
/*!40000 ALTER TABLE `interventions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lignecommandefournisseur`
--

DROP TABLE IF EXISTS `lignecommandefournisseur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lignecommandefournisseur` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `prix_unitaire` decimal(10,2) NOT NULL,
  `quantite` decimal(10,2) NOT NULL,
  `id_commande_fournisseur` int DEFAULT NULL,
  `id_produit` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKlxvf2rv0k19v915qcns5tqna1` (`id_commande_fournisseur`),
  KEY `FKink8tpchmo4eot2b81e35uldm` (`id_produit`),
  CONSTRAINT `FKink8tpchmo4eot2b81e35uldm` FOREIGN KEY (`id_produit`) REFERENCES `produits` (`id`),
  CONSTRAINT `FKlxvf2rv0k19v915qcns5tqna1` FOREIGN KEY (`id_commande_fournisseur`) REFERENCES `commandefournisseur` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lignecommandefournisseur`
--

LOCK TABLES `lignecommandefournisseur` WRITE;
/*!40000 ALTER TABLE `lignecommandefournisseur` DISABLE KEYS */;
/*!40000 ALTER TABLE `lignecommandefournisseur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ligneintervention`
--

DROP TABLE IF EXISTS `ligneintervention`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ligneintervention` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `numero_contrat` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `problematique` text COLLATE utf8mb4_general_ci,
  `quantite` decimal(10,2) NOT NULL,
  `id_intervention` int DEFAULT NULL,
  `id_produit` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7ocv7smxdafcg2yv084ufen1d` (`id_intervention`),
  KEY `FK1hbr05gldaokysvqk2chaamqo` (`id_produit`),
  CONSTRAINT `FK1hbr05gldaokysvqk2chaamqo` FOREIGN KEY (`id_produit`) REFERENCES `produits` (`id`),
  CONSTRAINT `FK7ocv7smxdafcg2yv084ufen1d` FOREIGN KEY (`id_intervention`) REFERENCES `interventions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ligneintervention`
--

LOCK TABLES `ligneintervention` WRITE;
/*!40000 ALTER TABLE `ligneintervention` DISABLE KEYS */;
INSERT INTO `ligneintervention` VALUES (120,'2026-03-30 13:42:29.182335',6,'2026-03-30 13:42:29.182335',NULL,NULL,1.00,7,8),(142,'2026-03-30 14:03:24.050839',6,'2026-03-30 14:03:24.050839',NULL,NULL,1.00,15,1),(143,'2026-03-30 14:03:24.064759',6,'2026-03-30 14:03:24.064759',NULL,NULL,1.00,15,18),(144,'2026-03-30 14:03:24.074926',6,'2026-03-30 14:03:24.074926',NULL,NULL,1.00,15,24),(154,'2026-04-01 14:20:30.572246',6,'2026-04-01 14:20:30.572246',NULL,NULL,1.00,2,9),(155,'2026-04-01 14:20:30.578900',6,'2026-04-01 14:20:30.578900',NULL,NULL,1.00,2,7),(156,'2026-04-01 14:20:30.587436',6,'2026-04-01 14:20:30.587436',NULL,NULL,2.00,2,24),(157,'2026-04-01 14:20:48.799345',6,'2026-04-01 14:20:48.799345',NULL,NULL,2.00,3,7),(158,'2026-04-01 14:20:48.806826',6,'2026-04-01 14:20:48.806826',NULL,NULL,1.00,3,6),(161,'2026-05-04 10:27:08.459877',6,'2026-05-04 10:27:08.459877',NULL,NULL,1.00,13,14),(162,'2026-05-04 10:30:57.952049',6,'2026-05-04 10:30:57.952049',NULL,NULL,1.00,17,10),(163,'2026-05-04 10:30:57.954779',6,'2026-05-04 10:30:57.954779',NULL,NULL,1.00,17,6),(164,'2026-05-04 10:30:57.957324',6,'2026-05-04 10:30:57.957324',NULL,NULL,1.00,17,24),(167,'2026-05-29 13:22:37.975754',6,'2026-05-29 13:22:37.975754',NULL,NULL,1.00,14,15),(168,'2026-05-29 13:22:37.987088',6,'2026-05-29 13:22:37.987088',NULL,NULL,1.00,14,6);
/*!40000 ALTER TABLE `ligneintervention` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ligneinterventionclient`
--

DROP TABLE IF EXISTS `ligneinterventionclient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ligneinterventionclient` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `numero_contrat` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `problematique` text COLLATE utf8mb4_general_ci,
  `quantite` decimal(10,2) NOT NULL,
  `id_intervention_client` int DEFAULT NULL,
  `id_produit` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbyrpm9je7k76gyx0w1ys0u4bk` (`id_intervention_client`),
  KEY `FK617xmo2pvhpb7w47o19p1av87` (`id_produit`),
  CONSTRAINT `FK617xmo2pvhpb7w47o19p1av87` FOREIGN KEY (`id_produit`) REFERENCES `produits` (`id`),
  CONSTRAINT `FKbyrpm9je7k76gyx0w1ys0u4bk` FOREIGN KEY (`id_intervention_client`) REFERENCES `interventionclient` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ligneinterventionclient`
--

LOCK TABLES `ligneinterventionclient` WRITE;
/*!40000 ALTER TABLE `ligneinterventionclient` DISABLE KEYS */;
/*!40000 ALTER TABLE `ligneinterventionclient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mvtstk`
--

DROP TABLE IF EXISTS `mvtstk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mvtstk` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `date_mvt` datetime(6) NOT NULL,
  `quantite` decimal(10,2) NOT NULL,
  `source_mvt` enum('COMMANDE_FOURNISSEUR','INTERVENTION','INTERVENTION_CLIENT') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type_mvt` enum('CORRECTION_NEG','CORRECTION_POS','ENTREE','SORTIE') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_produit` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK63tkosgmvljq5865ek4n5fco6` (`id_produit`),
  CONSTRAINT `FK63tkosgmvljq5865ek4n5fco6` FOREIGN KEY (`id_produit`) REFERENCES `produits` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mvtstk`
--

LOCK TABLES `mvtstk` WRITE;
/*!40000 ALTER TABLE `mvtstk` DISABLE KEYS */;
INSERT INTO `mvtstk` VALUES (59,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',15.00,'COMMANDE_FOURNISSEUR','ENTREE',1),(60,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',20.00,'COMMANDE_FOURNISSEUR','ENTREE',2),(61,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',10.00,'COMMANDE_FOURNISSEUR','ENTREE',3),(62,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',5.00,'COMMANDE_FOURNISSEUR','ENTREE',4),(63,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',3.00,'COMMANDE_FOURNISSEUR','ENTREE',5),(64,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',10.00,'COMMANDE_FOURNISSEUR','ENTREE',6),(65,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',8.00,'COMMANDE_FOURNISSEUR','ENTREE',7),(66,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',5.00,'COMMANDE_FOURNISSEUR','ENTREE',8),(67,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',50.00,'COMMANDE_FOURNISSEUR','ENTREE',9),(68,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',50.00,'COMMANDE_FOURNISSEUR','ENTREE',10),(69,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',30.00,'COMMANDE_FOURNISSEUR','ENTREE',11),(70,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',20.00,'COMMANDE_FOURNISSEUR','ENTREE',12),(71,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',15.00,'COMMANDE_FOURNISSEUR','ENTREE',13),(72,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',40.00,'COMMANDE_FOURNISSEUR','ENTREE',14),(73,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',30.00,'COMMANDE_FOURNISSEUR','ENTREE',15),(74,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',20.00,'COMMANDE_FOURNISSEUR','ENTREE',16),(75,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',25.00,'COMMANDE_FOURNISSEUR','ENTREE',17),(76,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',30.00,'COMMANDE_FOURNISSEUR','ENTREE',18),(77,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',25.00,'COMMANDE_FOURNISSEUR','ENTREE',19),(78,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',20.00,'COMMANDE_FOURNISSEUR','ENTREE',20),(79,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',15.00,'COMMANDE_FOURNISSEUR','ENTREE',21),(80,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',10.00,'COMMANDE_FOURNISSEUR','ENTREE',22),(81,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',5.00,'COMMANDE_FOURNISSEUR','ENTREE',23),(82,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',20.00,'COMMANDE_FOURNISSEUR','ENTREE',24),(83,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',25.00,'COMMANDE_FOURNISSEUR','ENTREE',25),(84,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',15.00,'COMMANDE_FOURNISSEUR','ENTREE',26),(85,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',40.00,'COMMANDE_FOURNISSEUR','ENTREE',27),(86,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',30.00,'COMMANDE_FOURNISSEUR','ENTREE',28),(87,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',20.00,'COMMANDE_FOURNISSEUR','ENTREE',29),(88,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',30.00,'COMMANDE_FOURNISSEUR','ENTREE',30),(89,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',25.00,'COMMANDE_FOURNISSEUR','ENTREE',31),(90,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',20.00,'COMMANDE_FOURNISSEUR','ENTREE',32),(91,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',20.00,'COMMANDE_FOURNISSEUR','ENTREE',33),(92,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',25.00,'COMMANDE_FOURNISSEUR','ENTREE',34),(93,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',10.00,'COMMANDE_FOURNISSEUR','ENTREE',35),(94,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',8.00,'COMMANDE_FOURNISSEUR','ENTREE',36),(95,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',20.00,'COMMANDE_FOURNISSEUR','ENTREE',37),(96,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',5.00,'COMMANDE_FOURNISSEUR','ENTREE',38),(97,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',8.00,'COMMANDE_FOURNISSEUR','ENTREE',39),(98,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',3.00,'COMMANDE_FOURNISSEUR','ENTREE',40),(99,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',10.00,'COMMANDE_FOURNISSEUR','ENTREE',41),(100,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',8.00,'COMMANDE_FOURNISSEUR','ENTREE',42),(101,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',6.00,'COMMANDE_FOURNISSEUR','ENTREE',43),(102,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',20.00,'COMMANDE_FOURNISSEUR','ENTREE',44),(103,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',15.00,'COMMANDE_FOURNISSEUR','ENTREE',45),(104,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',8.00,'COMMANDE_FOURNISSEUR','ENTREE',46),(105,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','2026-01-01 00:00:00.000000',100.00,'COMMANDE_FOURNISSEUR','ENTREE',47),(106,'2026-03-30 11:26:57.039325',6,'2026-03-30 11:26:57.039325','2026-03-30 11:26:57.013426',-1.00,'INTERVENTION','SORTIE',7),(107,'2026-03-30 11:27:15.453773',6,'2026-03-30 11:27:15.453773','2026-03-30 11:27:15.448424',-2.00,'INTERVENTION','SORTIE',7),(108,'2026-03-30 11:27:58.864467',6,'2026-03-30 11:27:58.864467','2026-03-30 11:27:58.861106',-1.00,'INTERVENTION','SORTIE',7),(109,'2026-03-30 11:45:15.651595',6,'2026-03-30 11:45:15.651595','2026-03-30 11:45:15.642598',-2.00,'INTERVENTION','SORTIE',1),(110,'2026-03-30 11:47:20.953132',6,'2026-03-30 11:47:20.953132','2026-03-30 11:47:20.947958',2.00,'INTERVENTION','ENTREE',1),(111,'2026-03-30 11:47:20.963638',6,'2026-03-30 11:47:20.963638','2026-03-30 11:47:20.959636',2.00,'INTERVENTION','ENTREE',1),(112,'2026-03-30 13:32:48.211671',6,'2026-03-30 13:32:48.211671','2026-03-30 13:32:48.113069',2.00,'INTERVENTION','ENTREE',1),(113,'2026-03-30 13:32:48.491322',6,'2026-03-30 13:32:48.491322','2026-03-30 13:32:48.478095',2.00,'INTERVENTION','ENTREE',1),(114,'2026-03-30 13:33:01.414604',6,'2026-03-30 13:33:01.414604','2026-03-30 13:33:01.407600',-1.00,'INTERVENTION','SORTIE',1),(115,'2026-03-30 13:33:51.198906',6,'2026-03-30 13:33:51.198906','2026-03-30 13:33:51.192383',-1.00,'INTERVENTION','SORTIE',9),(116,'2026-03-30 13:33:51.593429',6,'2026-03-30 13:33:51.593429','2026-03-30 13:33:51.581966',-2.00,'INTERVENTION','SORTIE',3),(117,'2026-03-30 13:34:17.950186',6,'2026-03-30 13:34:17.950186','2026-03-30 13:34:17.944309',1.00,'INTERVENTION','ENTREE',9),(118,'2026-03-30 13:34:17.965906',6,'2026-03-30 13:34:17.965906','2026-03-30 13:34:17.959504',2.00,'INTERVENTION','ENTREE',3),(119,'2026-03-30 13:34:32.409285',6,'2026-03-30 13:34:32.409285','2026-03-30 13:34:32.401380',-1.00,'INTERVENTION','SORTIE',9),(120,'2026-03-30 13:35:29.500924',6,'2026-03-30 13:35:29.500924','2026-03-30 13:35:29.495817',1.00,'INTERVENTION','ENTREE',7),(121,'2026-03-30 13:35:29.516072',6,'2026-03-30 13:35:29.516072','2026-03-30 13:35:29.509925',2.00,'INTERVENTION','ENTREE',7),(122,'2026-03-30 13:35:29.528588',6,'2026-03-30 13:35:29.528588','2026-03-30 13:35:29.521103',1.00,'INTERVENTION','ENTREE',7),(123,'2026-03-30 13:35:32.783135',6,'2026-03-30 13:35:32.783135','2026-03-30 13:35:32.776729',-2.00,'INTERVENTION','SORTIE',7),(124,'2026-03-30 13:37:25.463586',6,'2026-03-30 13:37:25.463586','2026-03-30 13:37:25.461816',1.00,'INTERVENTION','ENTREE',1),(125,'2026-03-30 13:39:29.067115',6,'2026-03-30 13:39:29.067115','2026-03-30 13:39:29.059828',1.00,'INTERVENTION','ENTREE',9),(126,'2026-03-30 13:39:33.880172',6,'2026-03-30 13:39:33.880172','2026-03-30 13:39:33.874546',-1.00,'INTERVENTION','SORTIE',9),(127,'2026-03-30 13:39:33.905365',6,'2026-03-30 13:39:33.905365','2026-03-30 13:39:33.898741',-1.00,'INTERVENTION','SORTIE',4),(128,'2026-03-30 13:39:33.930399',6,'2026-03-30 13:39:33.930399','2026-03-30 13:39:33.924515',-1.00,'INTERVENTION','SORTIE',24),(129,'2026-03-30 13:41:03.849815',6,'2026-03-30 13:41:03.849815','2026-03-30 13:41:03.844836',2.00,'INTERVENTION','ENTREE',7),(130,'2026-03-30 13:41:06.447773',6,'2026-03-30 13:41:06.447773','2026-03-30 13:41:06.441558',-2.00,'INTERVENTION','SORTIE',7),(131,'2026-03-30 13:41:06.471709',6,'2026-03-30 13:41:06.471709','2026-03-30 13:41:06.465909',-1.00,'INTERVENTION','SORTIE',9),(132,'2026-03-30 13:41:21.900413',6,'2026-03-30 13:41:21.900413','2026-03-30 13:41:21.895399',2.00,'INTERVENTION','ENTREE',7),(133,'2026-03-30 13:41:21.912765',6,'2026-03-30 13:41:21.912765','2026-03-30 13:41:21.907394',1.00,'INTERVENTION','ENTREE',9),(134,'2026-03-30 13:41:24.827399',6,'2026-03-30 13:41:24.827399','2026-03-30 13:41:24.822410',-2.00,'INTERVENTION','SORTIE',7),(135,'2026-03-30 13:41:24.849580',6,'2026-03-30 13:41:24.849580','2026-03-30 13:41:24.843560',-1.00,'INTERVENTION','SORTIE',9),(136,'2026-03-30 13:42:29.196353',6,'2026-03-30 13:42:29.196353','2026-03-30 13:42:29.182335',-1.00,'INTERVENTION','SORTIE',8),(137,'2026-03-30 13:44:01.645792',6,'2026-03-30 13:44:01.645792','2026-03-30 13:44:01.641585',-1.00,'INTERVENTION','SORTIE',14),(138,'2026-03-30 13:44:01.662072',6,'2026-03-30 13:44:01.662072','2026-03-30 13:44:01.658067',-1.00,'INTERVENTION','SORTIE',42),(139,'2026-03-30 13:45:05.859464',6,'2026-03-30 13:45:05.859464','2026-03-30 13:45:05.853749',1.00,'INTERVENTION','ENTREE',14),(140,'2026-03-30 13:45:05.868878',6,'2026-03-30 13:45:05.868878','2026-03-30 13:45:05.865870',1.00,'INTERVENTION','ENTREE',42),(141,'2026-03-30 13:45:08.831790',6,'2026-03-30 13:45:08.831790','2026-03-30 13:45:08.828945',-1.00,'INTERVENTION','SORTIE',14),(142,'2026-03-30 13:45:08.850510',6,'2026-03-30 13:45:08.850510','2026-03-30 13:45:08.846195',-1.00,'INTERVENTION','SORTIE',42),(143,'2026-03-30 13:45:30.226887',6,'2026-03-30 13:45:30.226887','2026-03-30 13:45:30.222885',1.00,'INTERVENTION','ENTREE',14),(144,'2026-03-30 13:45:30.238380',6,'2026-03-30 13:45:30.238380','2026-03-30 13:45:30.233810',1.00,'INTERVENTION','ENTREE',42),(145,'2026-03-30 13:45:31.575910',6,'2026-03-30 13:45:31.575910','2026-03-30 13:45:31.569514',-1.00,'INTERVENTION','SORTIE',14),(146,'2026-03-30 13:46:46.032292',6,'2026-03-30 13:46:46.032292','2026-03-30 13:46:46.025638',1.00,'INTERVENTION','ENTREE',14),(147,'2026-03-30 13:46:50.062312',6,'2026-03-30 13:46:50.062312','2026-03-30 13:46:50.058454',-1.00,'INTERVENTION','SORTIE',14),(148,'2026-03-30 13:46:50.080064',6,'2026-03-30 13:46:50.080064','2026-03-30 13:46:50.074289',-1.00,'INTERVENTION','SORTIE',14),(149,'2026-03-30 13:47:28.197419',6,'2026-03-30 13:47:28.197419','2026-03-30 13:47:28.192275',1.00,'INTERVENTION','ENTREE',14),(150,'2026-03-30 13:47:28.206273',6,'2026-03-30 13:47:28.206273','2026-03-30 13:47:28.197419',1.00,'INTERVENTION','ENTREE',14),(151,'2026-03-30 13:47:30.107547',6,'2026-03-30 13:47:30.107547','2026-03-30 13:47:30.099918',-1.00,'INTERVENTION','SORTIE',14),(152,'2026-03-30 13:48:42.608069',6,'2026-03-30 13:48:42.608069','2026-03-30 13:48:42.605348',2.00,'INTERVENTION','ENTREE',7),(153,'2026-03-30 13:48:42.620948',6,'2026-03-30 13:48:42.620948','2026-03-30 13:48:42.618030',1.00,'INTERVENTION','ENTREE',9),(154,'2026-03-30 13:48:44.636968',6,'2026-03-30 13:48:44.636968','2026-03-30 13:48:44.630212',-2.00,'INTERVENTION','SORTIE',7),(155,'2026-03-30 13:48:44.666460',6,'2026-03-30 13:48:44.666460','2026-03-30 13:48:44.660889',-1.00,'INTERVENTION','SORTIE',9),(156,'2026-03-30 13:48:44.690422',6,'2026-03-30 13:48:44.690422','2026-03-30 13:48:44.684613',-1.00,'INTERVENTION','SORTIE',14),(157,'2026-03-30 13:49:13.364738',6,'2026-03-30 13:49:13.364738','2026-03-30 13:49:13.364738',2.00,'INTERVENTION','ENTREE',7),(158,'2026-03-30 13:49:13.383958',6,'2026-03-30 13:49:13.383958','2026-03-30 13:49:13.377775',1.00,'INTERVENTION','ENTREE',9),(159,'2026-03-30 13:49:13.393978',6,'2026-03-30 13:49:13.393978','2026-03-30 13:49:13.390744',1.00,'INTERVENTION','ENTREE',14),(160,'2026-03-30 13:49:16.162451',6,'2026-03-30 13:49:16.162451','2026-03-30 13:49:16.158448',-2.00,'INTERVENTION','SORTIE',7),(161,'2026-03-30 13:49:16.185553',6,'2026-03-30 13:49:16.185553','2026-03-30 13:49:16.180765',-1.00,'INTERVENTION','SORTIE',9),(162,'2026-03-30 13:49:39.278356',6,'2026-03-30 13:49:39.278356','2026-03-30 13:49:39.269321',2.00,'INTERVENTION','ENTREE',7),(163,'2026-03-30 13:49:39.292289',6,'2026-03-30 13:49:39.292289','2026-03-30 13:49:39.288497',1.00,'INTERVENTION','ENTREE',9),(164,'2026-03-30 13:49:46.529014',6,'2026-03-30 13:49:46.529014','2026-03-30 13:49:46.524588',-2.00,'INTERVENTION','SORTIE',7),(165,'2026-03-30 13:49:46.547225',6,'2026-03-30 13:49:46.547225','2026-03-30 13:49:46.543813',-1.00,'INTERVENTION','SORTIE',9),(166,'2026-03-30 13:49:46.564534',6,'2026-03-30 13:49:46.564534','2026-03-30 13:49:46.561224',-1.00,'INTERVENTION','SORTIE',6),(167,'2026-03-30 13:50:35.549224',6,'2026-03-30 13:50:35.549224','2026-03-30 13:50:35.544409',-1.00,'INTERVENTION','SORTIE',15),(168,'2026-03-30 13:50:35.571361',6,'2026-03-30 13:50:35.571361','2026-03-30 13:50:35.565030',-1.00,'INTERVENTION','SORTIE',2),(169,'2026-03-30 13:51:00.135330',6,'2026-03-30 13:51:00.135330','2026-03-30 13:51:00.131963',1.00,'INTERVENTION','ENTREE',15),(170,'2026-03-30 13:51:00.145070',6,'2026-03-30 13:51:00.145070','2026-03-30 13:51:00.141926',1.00,'INTERVENTION','ENTREE',2),(171,'2026-03-30 13:52:52.028691',6,'2026-03-30 13:52:52.028691','2026-03-30 13:52:52.023469',-1.00,'INTERVENTION','SORTIE',15),(172,'2026-03-30 14:01:38.583316',6,'2026-03-30 14:01:38.583316','2026-03-30 14:01:38.538833',2.00,'INTERVENTION','ENTREE',7),(173,'2026-03-30 14:01:38.684494',6,'2026-03-30 14:01:38.684494','2026-03-30 14:01:38.684494',1.00,'INTERVENTION','ENTREE',9),(174,'2026-03-30 14:01:38.689807',6,'2026-03-30 14:01:38.689807','2026-03-30 14:01:38.689807',1.00,'INTERVENTION','ENTREE',6),(175,'2026-03-30 14:01:38.737067',6,'2026-03-30 14:01:38.737067','2026-03-30 14:01:38.737067',-2.00,'INTERVENTION','SORTIE',7),(176,'2026-03-30 14:01:38.749657',6,'2026-03-30 14:01:38.749657','2026-03-30 14:01:38.747643',-1.00,'INTERVENTION','SORTIE',6),(177,'2026-03-30 14:03:24.057558',6,'2026-03-30 14:03:24.057558','2026-03-30 14:03:24.057558',-1.00,'INTERVENTION','SORTIE',1),(178,'2026-03-30 14:03:24.070262',6,'2026-03-30 14:03:24.070262','2026-03-30 14:03:24.069258',-1.00,'INTERVENTION','SORTIE',18),(179,'2026-03-30 14:03:24.080458',6,'2026-03-30 14:03:24.080458','2026-03-30 14:03:24.079072',-1.00,'INTERVENTION','SORTIE',24),(180,'2026-03-30 14:51:50.097231',6,'2026-03-30 14:51:50.097231','2026-03-30 14:51:50.025996',1.00,'INTERVENTION','ENTREE',9),(181,'2026-03-30 14:51:50.338819',6,'2026-03-30 14:51:50.338819','2026-03-30 14:51:50.338819',1.00,'INTERVENTION','ENTREE',4),(182,'2026-03-30 14:51:50.355463',6,'2026-03-30 14:51:50.355463','2026-03-30 14:51:50.355463',1.00,'INTERVENTION','ENTREE',24),(183,'2026-03-30 14:51:50.436875',6,'2026-03-30 14:51:50.436875','2026-03-30 14:51:50.436875',-1.00,'INTERVENTION','SORTIE',9),(184,'2026-03-30 14:51:50.452145',6,'2026-03-30 14:51:50.452145','2026-03-30 14:51:50.449572',-1.00,'INTERVENTION','SORTIE',8),(185,'2026-03-30 14:51:50.458966',6,'2026-03-30 14:51:50.458966','2026-03-30 14:51:50.458966',-1.00,'INTERVENTION','SORTIE',24),(186,'2026-03-30 14:52:27.573225',6,'2026-03-30 14:52:27.573225','2026-03-30 14:52:27.573225',1.00,'INTERVENTION','ENTREE',9),(187,'2026-03-30 14:52:27.587532',6,'2026-03-30 14:52:27.587532','2026-03-30 14:52:27.587532',1.00,'INTERVENTION','ENTREE',8),(188,'2026-03-30 14:52:27.592521',6,'2026-03-30 14:52:27.592521','2026-03-30 14:52:27.592521',1.00,'INTERVENTION','ENTREE',24),(189,'2026-03-30 14:52:27.605451',6,'2026-03-30 14:52:27.605451','2026-03-30 14:52:27.602885',-1.00,'INTERVENTION','SORTIE',9),(190,'2026-03-30 14:52:27.613623',6,'2026-03-30 14:52:27.613623','2026-03-30 14:52:27.613623',-1.00,'INTERVENTION','SORTIE',7),(191,'2026-03-30 14:52:27.626140',6,'2026-03-30 14:52:27.626140','2026-03-30 14:52:27.626140',-1.00,'INTERVENTION','SORTIE',24),(192,'2026-03-30 14:53:12.418623',6,'2026-03-30 14:53:12.418623','2026-03-30 14:53:12.415535',1.00,'INTERVENTION','ENTREE',9),(193,'2026-03-30 14:53:12.422265',6,'2026-03-30 14:53:12.422265','2026-03-30 14:53:12.422265',1.00,'INTERVENTION','ENTREE',7),(194,'2026-03-30 14:53:12.429810',6,'2026-03-30 14:53:12.429810','2026-03-30 14:53:12.429810',1.00,'INTERVENTION','ENTREE',24),(195,'2026-03-30 14:53:12.444222',6,'2026-03-30 14:53:12.444222','2026-03-30 14:53:12.442214',-1.00,'INTERVENTION','SORTIE',9),(196,'2026-03-30 14:53:12.453182',6,'2026-03-30 14:53:12.453182','2026-03-30 14:53:12.453182',-1.00,'INTERVENTION','SORTIE',7),(197,'2026-03-30 14:53:12.464493',6,'2026-03-30 14:53:12.464493','2026-03-30 14:53:12.462481',-2.00,'INTERVENTION','SORTIE',24),(198,'2026-04-01 14:20:30.558852',6,'2026-04-01 14:20:30.558852','2026-04-01 14:20:30.556924',1.00,'INTERVENTION','ENTREE',9),(199,'2026-04-01 14:20:30.563508',6,'2026-04-01 14:20:30.563508','2026-04-01 14:20:30.563275',1.00,'INTERVENTION','ENTREE',7),(200,'2026-04-01 14:20:30.565840',6,'2026-04-01 14:20:30.565840','2026-04-01 14:20:30.565663',2.00,'INTERVENTION','ENTREE',24),(201,'2026-04-01 14:20:30.575999',6,'2026-04-01 14:20:30.575999','2026-04-01 14:20:30.575797',-1.00,'INTERVENTION','SORTIE',9),(202,'2026-04-01 14:20:30.585251',6,'2026-04-01 14:20:30.585251','2026-04-01 14:20:30.585064',-1.00,'INTERVENTION','SORTIE',7),(203,'2026-04-01 14:20:30.590940',6,'2026-04-01 14:20:30.590940','2026-04-01 14:20:30.590791',-2.00,'INTERVENTION','SORTIE',24),(204,'2026-04-01 14:20:48.790162',6,'2026-04-01 14:20:48.790162','2026-04-01 14:20:48.789733',2.00,'INTERVENTION','ENTREE',7),(205,'2026-04-01 14:20:48.795169',6,'2026-04-01 14:20:48.795169','2026-04-01 14:20:48.794884',1.00,'INTERVENTION','ENTREE',6),(206,'2026-04-01 14:20:48.802779',6,'2026-04-01 14:20:48.802779','2026-04-01 14:20:48.802601',-2.00,'INTERVENTION','SORTIE',7),(207,'2026-04-01 14:20:48.811010',6,'2026-04-01 14:20:48.811010','2026-04-01 14:20:48.810856',-1.00,'INTERVENTION','SORTIE',6),(208,'2026-04-01 14:22:54.574553',6,'2026-04-01 14:22:54.574553','2026-04-01 14:22:54.571358',1.00,'INTERVENTION','ENTREE',15),(209,'2026-04-01 14:22:54.611453',6,'2026-04-01 14:22:54.611453','2026-04-01 14:22:54.611142',-1.00,'INTERVENTION','SORTIE',15),(210,'2026-04-01 14:22:54.618040',6,'2026-04-01 14:22:54.618040','2026-04-01 14:22:54.617791',-1.00,'INTERVENTION','SORTIE',6),(211,'2026-05-04 10:27:08.387113',6,'2026-05-04 10:27:08.387113','2026-05-04 10:27:08.359773',1.00,'INTERVENTION','ENTREE',14),(212,'2026-05-04 10:27:08.466716',6,'2026-05-04 10:27:08.466716','2026-05-04 10:27:08.466233',-1.00,'INTERVENTION','SORTIE',14),(213,'2026-05-04 10:33:46.868113',6,'2026-05-04 10:33:46.868113','2026-05-04 10:33:46.867686',1.00,'INTERVENTION','ENTREE',15),(214,'2026-05-04 10:33:46.872695',6,'2026-05-04 10:33:46.872695','2026-05-04 10:33:46.872395',1.00,'INTERVENTION','ENTREE',6),(215,'2026-05-04 10:33:46.880316',6,'2026-05-04 10:33:46.880316','2026-05-04 10:33:46.880026',-1.00,'INTERVENTION','SORTIE',15),(216,'2026-05-04 10:33:46.887088',6,'2026-05-04 10:33:46.887088','2026-05-04 10:33:46.886886',-1.00,'INTERVENTION','SORTIE',6),(217,'2026-05-29 13:22:37.952104',6,'2026-05-29 13:22:37.952104','2026-05-29 13:22:37.950190',1.00,'INTERVENTION','ENTREE',15),(218,'2026-05-29 13:22:37.969672',6,'2026-05-29 13:22:37.969672','2026-05-29 13:22:37.969379',1.00,'INTERVENTION','ENTREE',6),(219,'2026-05-29 13:22:37.981495',6,'2026-05-29 13:22:37.981495','2026-05-29 13:22:37.981233',-1.00,'INTERVENTION','SORTIE',15),(220,'2026-05-29 13:22:37.989088',6,'2026-05-29 13:22:37.989088','2026-05-29 13:22:37.988863',-1.00,'INTERVENTION','SORTIE',6);
/*!40000 ALTER TABLE `mvtstk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produits`
--

DROP TABLE IF EXISTS `produits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `code_produit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `prix_unitaire_ht` decimal(10,2) DEFAULT NULL,
  `prix_unitaire_ttc` decimal(10,2) DEFAULT NULL,
  `taux_tva` decimal(5,2) DEFAULT NULL,
  `id_category` int DEFAULT NULL,
  `id_fournisseur` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK1qweis5g19snd4fsmnypquptd` (`code_produit`),
  KEY `FKe40poh6gfbjfaxoaubaqdvj9x` (`id_category`),
  KEY `FK3wwisme3ll7xrqt8bnsm646rh` (`id_fournisseur`),
  CONSTRAINT `FK3wwisme3ll7xrqt8bnsm646rh` FOREIGN KEY (`id_fournisseur`) REFERENCES `fournisseur` (`id`),
  CONSTRAINT `FKe40poh6gfbjfaxoaubaqdvj9x` FOREIGN KEY (`id_category`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produits`
--

LOCK TABLES `produits` WRITE;
/*!40000 ALTER TABLE `produits` DISABLE KEYS */;
INSERT INTO `produits` VALUES (1,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','CAM001','Camera IP Exterieure HD',NULL,150.00,180.00,20.00,1,1),(2,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','CAM002','Camera IP Interieure HD',NULL,120.00,144.00,20.00,1,1),(3,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','CAM003','Camera Dome Anti-Vandalisme',NULL,200.00,240.00,20.00,1,1),(4,'2026-01-01 00:00:00.000000',6,'2026-04-01 14:17:44.367453','CAM004','Camera PTZ 360',NULL,350.00,420.00,20.00,1,1),(5,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','CAM005','Camera Thermique Exterieure',NULL,800.00,960.00,20.00,1,1),(6,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','CEN001','Centrale Alarme 8 Zones',NULL,250.00,300.00,20.00,3,1),(7,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','CEN002','Centrale Alarme 16 Zones',NULL,450.00,540.00,20.00,3,1),(8,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','CEN003','Centrale Alarme GSM 32 Zones',NULL,650.00,780.00,20.00,3,1),(9,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','DOU001','Detecteur Ouverture Porte Magnetique',NULL,25.00,30.00,20.00,5,1),(10,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','DOU002','Detecteur Ouverture Fenetre',NULL,20.00,24.00,20.00,5,1),(11,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','DOU003','Detecteur Ouverture Sans Fil',NULL,35.00,42.00,20.00,5,1),(12,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','DBG001','Detecteur Bris de Glace Filaire',NULL,45.00,54.00,20.00,6,1),(13,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','DBG002','Detecteur Bris de Glace Sans Fil',NULL,60.00,72.00,20.00,6,1),(14,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','DMV001','Detecteur PIR Interieur',NULL,35.00,42.00,20.00,7,1),(15,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','DMV002','Detecteur PIR Exterieur',NULL,55.00,66.00,20.00,7,1),(16,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','DMV003','Detecteur Double Technologie',NULL,75.00,90.00,20.00,7,1),(17,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','DMV004','Detecteur PIR Sans Fil',NULL,65.00,78.00,20.00,7,1),(18,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','BTL001','Telecommande 4 Boutons',NULL,30.00,36.00,20.00,8,1),(19,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','BTL002','Bouton Panique',NULL,25.00,30.00,20.00,8,1),(20,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','BTL003','Telecommande Bidirectionnelle',NULL,45.00,54.00,20.00,8,1),(21,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','CLA001','Clavier LCD Filaire',NULL,120.00,144.00,20.00,9,1),(22,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','CLA002','Clavier Tactile Sans Fil',NULL,180.00,216.00,20.00,9,1),(23,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','CLA003','Clavier Biometrique',NULL,250.00,300.00,20.00,9,1),(24,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','SIR001','Sirene Exterieure Flash LED',NULL,80.00,96.00,20.00,10,1),(25,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','SIR002','Sirene Interieure 120dB',NULL,50.00,60.00,20.00,10,1),(26,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','SIR003','Sir?ne Sans Fil Ext?rieure',NULL,110.00,132.00,20.00,10,1),(27,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','ALI001','Alimentation 12V 2A',NULL,20.00,24.00,20.00,13,1),(28,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','ALI002','Alimentation 12V 5A',NULL,35.00,42.00,20.00,13,1),(29,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','ALI003','Batterie de Secours 7Ah',NULL,45.00,54.00,20.00,13,1),(30,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','INC001','D?tecteur Fum?e Optique',NULL,40.00,48.00,20.00,14,1),(31,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','INC002','D?tecteur Chaleur',NULL,45.00,54.00,20.00,14,1),(32,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','INC003','D?tecteur CO2',NULL,55.00,66.00,20.00,14,1),(33,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','FUI001','D?tecteur Fuite Gaz',NULL,60.00,72.00,20.00,15,1),(34,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','FUI002','D?tecteur Fuite Eau',NULL,35.00,42.00,20.00,15,1),(35,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','VID001','Enregistreur NVR 8 Canaux',NULL,300.00,360.00,20.00,19,1),(36,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','VID002','Enregistreur DVR 16 Canaux',NULL,450.00,540.00,20.00,19,1),(37,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','VID003','Disque Dur 2To Surveillance',NULL,80.00,96.00,20.00,19,1),(38,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','KIT001','Kit 4 Cam?ras + NVR + Disque',NULL,800.00,960.00,20.00,20,1),(39,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','KIT002','Kit Alarme Maison Complet',NULL,600.00,720.00,20.00,20,1),(40,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','KIT003','Kit Vid?osurveillance Pro 8 Cam?ras',NULL,1200.00,1440.00,20.00,20,1),(41,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','INT001','Interphone Vid?o 2 Fils',NULL,180.00,216.00,20.00,22,1),(42,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','INT002','Visiophone Connect? WiFi',NULL,250.00,300.00,20.00,22,1),(43,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','INT003','Portier Vid?o IP',NULL,350.00,420.00,20.00,22,1),(44,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','ACC001','Lecteur Badge RFID',NULL,90.00,108.00,20.00,23,1),(45,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','ACC002','?lectroserrure 12V',NULL,120.00,144.00,20.00,23,1),(46,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','ACC003','Contr?leur Acc?s 2 Portes',NULL,280.00,336.00,20.00,23,1),(47,'2026-01-01 00:00:00.000000',6,'2026-01-01 00:00:00.000000','ACC004','Badge RFID (lot de 10)',NULL,25.00,30.00,20.00,23,1);
/*!40000 ALTER TABLE `produits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `role_name` enum('ROLE_ADMIN','ROLE_CLIENT','ROLE_MANAGER','ROLE_TECHNICIEN') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_utilisateur` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKnj2ecd8t8i7wmxfrl1mq8gql3` (`id_utilisateur`),
  CONSTRAINT `FKnj2ecd8t8i7wmxfrl1mq8gql3` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (7,'2026-03-16 17:12:07.798474',NULL,'2026-03-16 17:12:07.798474','ROLE_ADMIN',NULL),(8,'2026-03-17 10:38:49.410456',NULL,'2026-03-17 10:38:49.410456','ROLE_ADMIN',NULL),(9,'2026-05-02 15:38:17.000000',6,'2026-05-02 15:38:17.000000','ROLE_ADMIN',8);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilisateur` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) NOT NULL,
  `id_entreprise` int DEFAULT NULL,
  `last_update_date` datetime(6) NOT NULL,
  `date_de_naissance` date DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fonction` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `prenom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_adresse` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKrma38wvnqfaf66vvmi57c71lo` (`email`),
  UNIQUE KEY `UKbs9ossrfw71n39gcfsn6ftppe` (`id_adresse`),
  KEY `FKlmpv6937sit6tiqf7bbuycmby` (`id_entreprise`),
  CONSTRAINT `FKlmpv6937sit6tiqf7bbuycmby` FOREIGN KEY (`id_entreprise`) REFERENCES `entreprise` (`id`),
  CONSTRAINT `FKnyi5gbai4jrvhqq5qeyabkqkb` FOREIGN KEY (`id_adresse`) REFERENCES `adresse` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateur`
--

LOCK TABLES `utilisateur` WRITE;
/*!40000 ALTER TABLE `utilisateur` DISABLE KEYS */;
INSERT INTO `utilisateur` VALUES (8,'2026-03-17 10:38:49.363911',6,'2026-03-24 09:41:14.365966','1990-01-01','admin@macsecurite.fr','ADMIN','Admin','$2a$10$E4hZniPrBiU0rZBswenUcOAryy6NSdlcS9UI5emoir3HDaoMwid4y',NULL,'MacSpace',15),(9,'2026-03-25 23:56:03.000000',6,'2026-03-25 23:56:03.000000',NULL,'jean.macalou@macsecurite.fr','TECHNICIEN','Macalou','$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',NULL,'Jean',NULL),(10,'2026-03-25 23:56:03.000000',6,'2026-03-25 23:56:03.000000',NULL,'steeve.mac@macsecurite.fr','TECHNICIEN','Mac','$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',NULL,'Steeve',NULL),(11,'2026-03-25 23:56:03.000000',6,'2026-03-25 23:56:03.000000',NULL,'cyril.tech@macsecurite.fr','TECHNICIEN','Tech','$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',NULL,'Cyril',NULL),(12,'2026-03-26 14:04:30.216688',6,'2026-03-26 14:04:30.216688',NULL,'gm@gmail.com','TECHNICIEN','Mendez','$2a$10$CpFadpXJ2gd0/9BN1N5OFe48arD7.1FXjJ/IcIlPvc/1D4j7dlj0y',NULL,'Barry',NULL);
/*!40000 ALTER TABLE `utilisateur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vue_interventions_par_mois`
--

DROP TABLE IF EXISTS `vue_interventions_par_mois`;
/*!50001 DROP VIEW IF EXISTS `vue_interventions_par_mois`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vue_interventions_par_mois` AS SELECT 
 1 AS `annee`,
 1 AS `nom_mois`,
 1 AS `mois`,
 1 AS `nb_interventions`,
 1 AS `total_produits_utilises`,
 1 AS `nb_terminees`,
 1 AS `taux_resolution`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vue_performance_techniciens`
--

DROP TABLE IF EXISTS `vue_performance_techniciens`;
/*!50001 DROP VIEW IF EXISTS `vue_performance_techniciens`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vue_performance_techniciens` AS SELECT 
 1 AS `nom`,
 1 AS `prenom`,
 1 AS `fonction`,
 1 AS `nb_interventions`,
 1 AS `nb_terminees`,
 1 AS `nb_en_attente`,
 1 AS `nb_en_cours`,
 1 AS `taux_resolution`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vue_produits_plus_utilises`
--

DROP TABLE IF EXISTS `vue_produits_plus_utilises`;
/*!50001 DROP VIEW IF EXISTS `vue_produits_plus_utilises`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vue_produits_plus_utilises` AS SELECT 
 1 AS `code_produit`,
 1 AS `designation`,
 1 AS `categorie`,
 1 AS `nb_mouvements`,
 1 AS `total_sorties`,
 1 AS `total_entrees`,
 1 AS `stock_net`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vue_tableau_bord_global`
--

DROP TABLE IF EXISTS `vue_tableau_bord_global`;
/*!50001 DROP VIEW IF EXISTS `vue_tableau_bord_global`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vue_tableau_bord_global` AS SELECT 
 1 AS `total_interventions`,
 1 AS `nb_techniciens_actifs`,
 1 AS `taux_resolution_global`,
 1 AS `total_produits_utilises`,
 1 AS `total_mouvements_stock`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'railway'
--

--
-- Final view structure for view `vue_interventions_par_mois`
--

/*!50001 DROP VIEW IF EXISTS `vue_interventions_par_mois`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vue_interventions_par_mois` AS select `dt`.`annee` AS `annee`,`dt`.`nom_mois` AS `nom_mois`,`dt`.`mois` AS `mois`,count(`fi`.`id`) AS `nb_interventions`,sum(`fi`.`nb_produits`) AS `total_produits_utilises`,sum((case when (`fi`.`etat` = 'TERMINEE') then 1 else 0 end)) AS `nb_terminees`,round(((sum((case when (`fi`.`etat` = 'TERMINEE') then 1 else 0 end)) * 100.0) / count(`fi`.`id`)),2) AS `taux_resolution` from (`dw_faits_interventions` `fi` join `dw_dim_temps` `dt` on((`fi`.`date_id` = `dt`.`id`))) group by `dt`.`annee`,`dt`.`mois`,`dt`.`nom_mois` order by `dt`.`annee`,`dt`.`mois` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vue_performance_techniciens`
--

/*!50001 DROP VIEW IF EXISTS `vue_performance_techniciens`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vue_performance_techniciens` AS select `dtech`.`nom` AS `nom`,`dtech`.`prenom` AS `prenom`,`dtech`.`fonction` AS `fonction`,count(`fi`.`id`) AS `nb_interventions`,sum((case when (`fi`.`etat` = 'TERMINEE') then 1 else 0 end)) AS `nb_terminees`,sum((case when (`fi`.`etat` = 'EN_ATTENTE') then 1 else 0 end)) AS `nb_en_attente`,sum((case when (`fi`.`etat` = 'EN_COURS') then 1 else 0 end)) AS `nb_en_cours`,round(((sum((case when (`fi`.`etat` = 'TERMINEE') then 1 else 0 end)) * 100.0) / count(`fi`.`id`)),2) AS `taux_resolution` from (`dw_faits_interventions` `fi` join `dw_dim_technicien` `dtech` on((`fi`.`technicien_id` = `dtech`.`id`))) group by `dtech`.`id`,`dtech`.`nom`,`dtech`.`prenom`,`dtech`.`fonction` order by `nb_interventions` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vue_produits_plus_utilises`
--

/*!50001 DROP VIEW IF EXISTS `vue_produits_plus_utilises`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vue_produits_plus_utilises` AS select `dp`.`code_produit` AS `code_produit`,`dp`.`designation` AS `designation`,`dp`.`categorie` AS `categorie`,count(`fs`.`id`) AS `nb_mouvements`,sum((case when (`fs`.`type_mvt` = 'SORTIE') then abs(`fs`.`quantite`) else 0 end)) AS `total_sorties`,sum((case when (`fs`.`type_mvt` = 'ENTREE') then `fs`.`quantite` else 0 end)) AS `total_entrees`,sum(`fs`.`quantite`) AS `stock_net` from (`dw_faits_stock` `fs` join `dw_dim_produit` `dp` on((`fs`.`produit_id` = `dp`.`id`))) group by `dp`.`id`,`dp`.`code_produit`,`dp`.`designation`,`dp`.`categorie` order by `total_sorties` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vue_tableau_bord_global`
--

/*!50001 DROP VIEW IF EXISTS `vue_tableau_bord_global`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vue_tableau_bord_global` AS select count(distinct `fi`.`intervention_id`) AS `total_interventions`,count(distinct `fi`.`technicien_id`) AS `nb_techniciens_actifs`,round(((sum((case when (`fi`.`etat` = 'TERMINEE') then 1 else 0 end)) * 100.0) / count(`fi`.`id`)),2) AS `taux_resolution_global`,sum(`fi`.`nb_produits`) AS `total_produits_utilises`,count(distinct `fs`.`mvt_id`) AS `total_mouvements_stock` from (`dw_faits_interventions` `fi` join (select count(0) AS `total_mouvements_stock`,count(distinct `dw_faits_stock`.`mvt_id`) AS `mvt_id` from `dw_faits_stock`) `fs`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-18  2:46:16
